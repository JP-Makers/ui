#!/usr/bin/env python3
"""
Main script for testing the custom OCR system.
Extracts text from images and PDFs and prints the output.
"""

import os
import sys
import argparse
from ocr import CustomOCR

def main():
    """
    Main function to run the OCR system.
    """
    parser = argparse.ArgumentParser(description='Custom OCR System - Extract text from images and PDFs')
    parser.add_argument('input_path', help='Path to image or PDF file')
    parser.add_argument('--confidence', type=float, default=0.7, 
                       help='Confidence threshold for character recognition (0.0-1.0)')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode for detailed output')
    
    args = parser.parse_args()
    
    # Check if input file exists
    if not os.path.exists(args.input_path):
        print(f"Error: File '{args.input_path}' not found.")
        sys.exit(1)
    
    # Initialize OCR system
    ocr = CustomOCR()
    ocr.set_confidence_threshold(args.confidence)
    
    # Determine file type and extract text
    file_extension = os.path.splitext(args.input_path)[1].lower()
    
    print(f"Processing file: {args.input_path}")
    print(f"Confidence threshold: {args.confidence}")
    print("-" * 50)
    
    try:
        if file_extension == '.pdf':
            if args.debug:
                print("DEBUG: Using PDF extraction mode")
            text = ocr.extract_text_from_pdf(args.input_path, debug=args.debug)
        elif file_extension in ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff']:
            if args.debug:
                print("DEBUG: Using image extraction mode")
            text = ocr.extract_text_from_image(args.input_path)
        else:
            print(f"Error: Unsupported file format '{file_extension}'")
            print("Supported formats: PDF, PNG, JPG, JPEG, GIF, BMP, TIFF")
            sys.exit(1)
        
        # Print extracted text
        if text and text.strip():
            print("Extracted Text:")
            print("=" * 50)
            print(text)
            print("=" * 50)
            print(f"Total characters extracted: {len(text)}")
        else:
            print("No readable text found in the file.")
            print("This could mean:")
            print("- The PDF contains only images without text")
            print("- The text is in a format not supported by this OCR system")
            print("- The PDF is password protected or corrupted")
            
    except Exception as e:
        print(f"Error processing file: {str(e)}")
        if args.debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)

def test_with_sample_files():
    """
    Test function to demonstrate OCR capabilities with sample files.
    """
    print("Custom OCR System Test")
    print("=" * 50)
    
    ocr = CustomOCR()
    
    # Test with different file types if they exist
    test_files = [
        "sample.png",
        "sample.jpg", 
        "sample.pdf",
        "test_image.png",
        "document.pdf"
    ]
    
    for file_path in test_files:
        if os.path.exists(file_path):
            print(f"\nProcessing: {file_path}")
            print("-" * 30)
            
            try:
                if file_path.endswith('.pdf'):
                    text = ocr.extract_text_from_pdf(file_path)
                else:
                    text = ocr.extract_text_from_image(file_path)
                
                if text:
                    print("Extracted text:")
                    print(text)
                else:
                    print("No text found.")
                    
            except Exception as e:
                print(f"Error: {str(e)}")
    
    if not any(os.path.exists(f) for f in test_files):
        print("No test files found.")
        print("To test the OCR system, run:")
        print("python main.py <image_or_pdf_file>")
        print("\nExample usage:")
        print("python main.py sample.png")
        print("python main.py document.pdf")
        print("python main.py image.jpg --confidence 0.8")

if __name__ == "__main__":
    if len(sys.argv) == 1:
        # No arguments provided, run test
        test_with_sample_files()
    else:
        # Arguments provided, run main OCR
        main()
