# Custom OCR System

## Overview

This is a custom OCR (Optical Character Recognition) system implemented in Python without external OCR dependencies. The system extracts text from images and PDFs using template matching algorithms and custom image processing techniques. It supports various image formats (PNG, JPG, JPEG, GIF, BMP, TIFF) and PDF files.

## System Architecture

The system follows a modular architecture with clear separation of concerns:

1. **Main Entry Point** (`main.py`): Command-line interface for processing files
2. **Core OCR Engine** (`ocr.py`): Central orchestrator that coordinates all components
3. **Template System** (`templates/characters.py`): Character recognition using predefined templates
4. **Image Processing** (`utils/image_processing.py`): Image preprocessing and text region extraction
5. **PDF Handling** (`utils/pdf_handler.py`): PDF text extraction and image conversion

## Key Components

### OCR Engine (`CustomOCR`)
- **Purpose**: Main coordination class that manages the entire OCR pipeline
- **Features**: 
  - Configurable confidence threshold for character recognition
  - Support for both image and PDF processing
  - Template-based character recognition

### Template Matching System
- **Approach**: Uses binary templates for character recognition
- **Template Size**: 20x30 pixels (width x height)
- **Rationale**: Chosen for simplicity and no external dependencies, though may have lower accuracy than ML-based approaches

### Image Processing Pipeline
- **Preprocessing Steps**:
  - Grayscale conversion
  - Contrast enhancement
  - Gaussian blur for noise reduction
  - Adaptive thresholding for binarization
  - Morphological noise removal
- **Text Region Extraction**: Identifies areas containing text
- **Character Segmentation**: Isolates individual characters for recognition

### PDF Processing
- **Primary Method**: PyMuPDF (fitz) for direct text extraction
- **Fallback**: Basic PDF text extraction without external dependencies
- **Image Extraction**: Converts PDF pages to images for OCR processing

## Data Flow

1. **Input**: User provides image or PDF file path via command line
2. **File Type Detection**: System determines processing method based on file extension
3. **Preprocessing**: 
   - Images: Direct processing through image pipeline
   - PDFs: Text extraction first, then image conversion if needed
4. **Text Region Extraction**: Identifies areas containing text
5. **Character Recognition**: Template matching against predefined character sets
6. **Output**: Extracted text printed to console

## External Dependencies

- **PIL (Pillow)**: Image processing and manipulation
- **NumPy**: Numerical operations and array handling
- **OpenCV**: Advanced image processing operations
- **PyMuPDF (fitz)**: PDF processing (optional with fallback)

The system is designed to gracefully handle missing optional dependencies by providing fallback implementations.

## Deployment Strategy

The system is designed as a standalone command-line application:
- **Execution**: `python main.py <input_path> [--confidence 0.7]`
- **Requirements**: Python 3.x with specified dependencies
- **Portability**: Cross-platform compatibility through Python and standard libraries

## Changelog

- July 04, 2025. Initial setup
- July 04, 2025. Complete OCR system implementation with image and PDF processing capabilities

## User Preferences

Preferred communication style: Simple, everyday language.