import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from typing import List, Tuple, Optional

# Try to import OpenCV, fallback to basic implementation if not available
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

class ImageProcessor:
    """
    Image processing utilities for the OCR system.
    Handles image preprocessing, text region extraction, and character segmentation.
    """
    
    def __init__(self):
        self.standard_char_size = (20, 30)  # width, height
        
    def preprocess_image(self, image: Image.Image) -> np.ndarray:
        """
        Preprocess an image for OCR by applying various filters and transformations.
        
        Args:
            image: PIL Image object
            
        Returns:
            Processed binary image as numpy array
        """
        # Convert to grayscale
        if image.mode != 'L':
            image = image.convert('L')
        
        # Enhance contrast
        enhancer = ImageEnhance.Contrast(image)
        image = enhancer.enhance(2.0)
        
        # Apply slight blur to reduce noise
        image = image.filter(ImageFilter.GaussianBlur(radius=0.5))
        
        # Convert to numpy array
        img_array = np.array(image)
        
        # Apply adaptive thresholding for binarization
        binary_image = self._adaptive_threshold(img_array)
        
        # Remove noise using morphological operations
        binary_image = self._remove_noise(binary_image)
        
        return binary_image
    
    def _adaptive_threshold(self, image: np.ndarray) -> np.ndarray:
        """
        Apply adaptive thresholding to create a binary image.
        
        Args:
            image: Grayscale image array
            
        Returns:
            Binary image array
        """
        # Simple adaptive thresholding implementation
        height, width = image.shape
        binary = np.zeros_like(image)
        
        # Calculate local threshold for each pixel
        kernel_size = 15
        half_kernel = kernel_size // 2
        
        for i in range(height):
            for j in range(width):
                # Define local region
                y_start = max(0, i - half_kernel)
                y_end = min(height, i + half_kernel + 1)
                x_start = max(0, j - half_kernel)
                x_end = min(width, j + half_kernel + 1)
                
                # Calculate local mean
                local_region = image[y_start:y_end, x_start:x_end]
                local_mean = np.mean(local_region)
                
                # Apply threshold
                if image[i, j] < local_mean - 10:
                    binary[i, j] = 0  # Black (text)
                else:
                    binary[i, j] = 255  # White (background)
        
        return binary
    
    def _remove_noise(self, binary_image: np.ndarray) -> np.ndarray:
        """
        Remove noise from binary image using morphological operations.
        
        Args:
            binary_image: Binary image array
            
        Returns:
            Cleaned binary image array
        """
        # Simple morphological operations
        kernel = np.ones((2, 2), np.uint8)
        
        # Opening (erosion followed by dilation)
        eroded = self._erode(binary_image, kernel)
        opened = self._dilate(eroded, kernel)
        
        return opened
    
    def _erode(self, image: np.ndarray, kernel: np.ndarray) -> np.ndarray:
        """
        Simple erosion implementation.
        """
        height, width = image.shape
        k_height, k_width = kernel.shape
        result = np.copy(image)
        
        for i in range(k_height//2, height - k_height//2):
            for j in range(k_width//2, width - k_width//2):
                region = image[i-k_height//2:i+k_height//2+1, j-k_width//2:j+k_width//2+1]
                if np.all(region == 0):
                    result[i, j] = 0
                else:
                    result[i, j] = 255
        
        return result
    
    def _dilate(self, image: np.ndarray, kernel: np.ndarray) -> np.ndarray:
        """
        Simple dilation implementation.
        """
        height, width = image.shape
        k_height, k_width = kernel.shape
        result = np.copy(image)
        
        for i in range(k_height//2, height - k_height//2):
            for j in range(k_width//2, width - k_width//2):
                region = image[i-k_height//2:i+k_height//2+1, j-k_width//2:j+k_width//2+1]
                if np.any(region == 0):
                    result[i, j] = 0
                else:
                    result[i, j] = 255
        
        return result
    
    def extract_text_regions(self, binary_image: np.ndarray) -> List[np.ndarray]:
        """
        Extract text regions from a binary image.
        
        Args:
            binary_image: Binary image array
            
        Returns:
            List of text regions as numpy arrays
        """
        # Find text lines using horizontal projection
        horizontal_projection = np.sum(binary_image == 0, axis=1)
        
        # Find text line boundaries
        text_lines = []
        in_text = False
        line_start = 0
        
        for i, projection in enumerate(horizontal_projection):
            if projection > 0 and not in_text:
                # Start of text line
                line_start = i
                in_text = True
            elif projection == 0 and in_text:
                # End of text line
                if i - line_start > 5:  # Minimum line height
                    text_lines.append((line_start, i))
                in_text = False
        
        # Handle case where text continues to the end
        if in_text:
            text_lines.append((line_start, len(horizontal_projection)))
        
        # Extract text regions
        regions = []
        for start, end in text_lines:
            region = binary_image[start:end, :]
            if region.size > 0:
                regions.append(region)
        
        return regions
    
    def segment_characters(self, text_region: np.ndarray) -> List[np.ndarray]:
        """
        Segment individual characters from a text region.
        
        Args:
            text_region: Binary image containing a line of text
            
        Returns:
            List of character images
        """
        # Vertical projection to find character boundaries
        vertical_projection = np.sum(text_region == 0, axis=0)
        
        # Find character boundaries
        characters = []
        in_char = False
        char_start = 0
        
        for i, projection in enumerate(vertical_projection):
            if projection > 0 and not in_char:
                # Start of character
                char_start = i
                in_char = True
            elif projection == 0 and in_char:
                # End of character
                if i - char_start > 3:  # Minimum character width
                    char_image = text_region[:, char_start:i]
                    characters.append(char_image)
                in_char = False
        
        # Handle case where character continues to the end
        if in_char:
            char_image = text_region[:, char_start:]
            characters.append(char_image)
        
        return characters
    
    def normalize_character_size(self, char_image: np.ndarray) -> np.ndarray:
        """
        Normalize character image to standard size.
        
        Args:
            char_image: Character image array
            
        Returns:
            Normalized character image
        """
        if char_image.size == 0:
            return np.zeros(self.standard_char_size[::-1], dtype=np.uint8)
        
        # Convert to PIL Image for resizing
        pil_image = Image.fromarray(char_image)
        
        # Resize to standard size
        resized = pil_image.resize(self.standard_char_size, 0)  # 0 = NEAREST
        
        return np.array(resized)
    
    def resize_image(self, image: np.ndarray, target_shape: Tuple[int, int]) -> np.ndarray:
        """
        Resize image to target shape.
        
        Args:
            image: Input image array
            target_shape: Target shape (height, width)
            
        Returns:
            Resized image array
        """
        pil_image = Image.fromarray(image)
        resized = pil_image.resize((target_shape[1], target_shape[0]), 0)  # 0 = NEAREST
        return np.array(resized)
