import io
from PIL import Image
from typing import List, Optional
import re

# Try to import PyMuPDF, fallback to basic implementation if not available
try:
    import fitz
    FITZ_AVAILABLE = True
except ImportError:
    FITZ_AVAILABLE = False

class PDFHandler:
    """
    PDF processing utilities for extracting text and images from PDF files.
    """
    
    def __init__(self):
        self.supported_image_formats = ['png', 'jpg', 'jpeg', 'gif', 'bmp', 'tiff']
        
    def extract_direct_text(self, pdf_path: str) -> str:
        """
        Extract direct text content from PDF (not from images).
        
        Args:
            pdf_path: Path to PDF file
            
        Returns:
            Extracted text as string
        """
        try:
            # Try using PyMuPDF first
            if FITZ_AVAILABLE:
                doc = fitz.open(pdf_path)
                text = ""
                for page in doc:
                    text += page.get_text()
                doc.close()
                return text
            else:
                # Fallback to basic PDF text extraction
                return self._basic_pdf_text_extraction(pdf_path)
                
        except Exception as e:
            print(f"Error extracting text from PDF: {str(e)}")
            return ""
    
    def _basic_pdf_text_extraction(self, pdf_path: str) -> str:
        """
        Basic PDF text extraction without external dependencies.
        This is a simplified approach that may not work for all PDFs.
        """
        try:
            with open(pdf_path, 'rb') as file:
                content = file.read().decode('latin-1', errors='ignore')
                
            # Simple regex to extract text between stream objects
            # This is a very basic approach and may not work for complex PDFs
            text_pattern = r'BT\s*(.*?)\s*ET'
            text_matches = re.findall(text_pattern, content, re.DOTALL)
            
            extracted_text = ""
            for match in text_matches:
                # Extract text from PDF text commands
                text_commands = re.findall(r'\((.*?)\)', match)
                for text_cmd in text_commands:
                    # Clean up the text
                    clean_text = text_cmd.replace('\\n', '\n').replace('\\r', '\r')
                    extracted_text += clean_text + " "
            
            return extracted_text.strip()
            
        except Exception as e:
            print(f"Error in basic PDF text extraction: {str(e)}")
            return ""
    
    def extract_images_from_pdf(self, pdf_path: str) -> List[bytes]:
        """
        Extract images from PDF file.
        
        Args:
            pdf_path: Path to PDF file
            
        Returns:
            List of image data as bytes
        """
        try:
            # Try using PyMuPDF first
            try:
                import fitz
                doc = fitz.open(pdf_path)
                images = []
                
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    image_list = page.get_images(full=True)
                    
                    for img_index, img in enumerate(image_list):
                        # Extract image
                        xref = img[0]
                        pix = fitz.Pixmap(doc, xref)
                        
                        if pix.n - pix.alpha < 4:  # GRAY or RGB
                            img_data = pix.tobytes("png")
                            images.append(img_data)
                        
                        pix = None
                
                doc.close()
                return images
                
            except ImportError:
                # Fallback to basic image extraction
                return self._basic_pdf_image_extraction(pdf_path)
                
        except Exception as e:
            print(f"Error extracting images from PDF: {str(e)}")
            return []
    
    def _basic_pdf_image_extraction(self, pdf_path: str) -> List[bytes]:
        """
        Basic PDF image extraction without external dependencies.
        This is a simplified approach that may not work for all PDFs.
        """
        try:
            with open(pdf_path, 'rb') as file:
                content = file.read()
            
            images = []
            
            # Look for common image markers in PDF
            # This is a very basic approach and may not work for all PDFs
            image_markers = [
                b'\\xFF\\xD8\\xFF',  # JPEG
                b'\\x89PNG\\r\\n\\x1a\\n',  # PNG
                b'GIF87a',  # GIF87a
                b'GIF89a',  # GIF89a
            ]
            
            for marker in image_markers:
                start = 0
                while True:
                    pos = content.find(marker, start)
                    if pos == -1:
                        break
                    
                    # Try to extract image data
                    # This is very basic and may not work properly
                    end_pos = pos + 1000  # Arbitrary limit
                    if end_pos > len(content):
                        end_pos = len(content)
                    
                    potential_image = content[pos:end_pos]
                    images.append(potential_image)
                    
                    start = pos + 1
            
            return images
            
        except Exception as e:
            print(f"Error in basic PDF image extraction: {str(e)}")
            return []
    
    def is_pdf_file(self, file_path: str) -> bool:
        """
        Check if file is a valid PDF.
        
        Args:
            file_path: Path to file
            
        Returns:
            True if file is PDF, False otherwise
        """
        try:
            with open(file_path, 'rb') as file:
                header = file.read(4)
                return header == b'%PDF'
        except:
            return False
    
    def get_pdf_info(self, pdf_path: str) -> dict:
        """
        Get basic information about the PDF.
        
        Args:
            pdf_path: Path to PDF file
            
        Returns:
            Dictionary with PDF information
        """
        try:
            # Try using PyMuPDF first
            try:
                import fitz
                doc = fitz.open(pdf_path)
                info = {
                    'page_count': len(doc),
                    'title': doc.metadata.get('title', ''),
                    'author': doc.metadata.get('author', ''),
                    'subject': doc.metadata.get('subject', ''),
                    'keywords': doc.metadata.get('keywords', ''),
                }
                doc.close()
                return info
            except ImportError:
                # Basic info extraction
                return {
                    'page_count': 1,  # Default assumption
                    'title': '',
                    'author': '',
                    'subject': '',
                    'keywords': '',
                }
                
        except Exception as e:
            print(f"Error getting PDF info: {str(e)}")
            return {}
