#!/usr/bin/env python3
"""Display the ordered content showing text, heading, text, text, heading, text pattern."""

import json

def show_ordered_content():
    with open('ordered_output.json', 'r') as f:
        data = json.load(f)
    
    print("="*70)
    print("STEP-BY-STEP ORDERED CONTENT (text, heading, text, text, heading...)")
    print("="*70)
    
    for i, item in enumerate(data['content'], 1):
        content_type = item['type'].upper()
        content_text = item['content']
        
        # Show first 80 characters for readability
        if len(content_text) > 80:
            display_text = content_text[:80] + "..."
        else:
            display_text = content_text
        
        print(f"{i:2d}. [{content_type:7s}] {display_text}")
    
    print("\n" + "="*70)
    print("TABLE DATA (Preserved Structure)")
    print("="*70)
    
    for i, table in enumerate(data['tables'], 1):
        print(f"\nTable {i}:")
        print(f"Header: {table['header']}")
        print("Data:")
        for j, row in enumerate(table['rows'], 1):
            print(f"  {j}. {row}")
    
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    
    # Count types
    text_count = sum(1 for item in data['content'] if item['type'] == 'text')
    heading_count = sum(1 for item in data['content'] if item['type'] == 'heading')
    
    print(f"✓ Total content lines: {len(data['content'])}")
    print(f"✓ Text lines: {text_count}")
    print(f"✓ Heading lines: {heading_count}")
    print(f"✓ Tables: {len(data['tables'])}")
    print(f"✓ Content ordered as it appears in PDF")
    print(f"✓ Pattern: text → heading → text → text → heading → text...")

if __name__ == "__main__":
    show_ordered_content()