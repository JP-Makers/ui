#!/usr/bin/env python3
"""
Simple PDF text and table extractor with clean JSON output.
Extracts content from PDFs and outputs minimal JSON format.
"""

import argparse
import json
import logging
import re
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional

import pdfplumber
import pandas as pd


class SimplePDFExtractor:
    """Simple PDF extraction class for clean text and table output."""
    
    def __init__(self):
        # Setup minimal logging
        logging.basicConfig(
            level=logging.ERROR,  # Only show errors
            format='%(message)s'
        )
        self.logger = logging.getLogger(__name__)
    
    def extract_pdf_content(self, pdf_path: str) -> Dict[str, Any]:
        """
        Extract text and table content from PDF file.
        
        Args:
            pdf_path: Path to PDF file
            
        Returns:
            Dictionary containing extracted content
        """
        try:
            pdf_file = Path(pdf_path)
            if not pdf_file.exists():
                raise FileNotFoundError(f"PDF file not found: {pdf_path}")
            
            extracted_content = {
                "content": [],
                "tables": []
            }
            
            with pdfplumber.open(pdf_path) as pdf:
                for page_num, page in enumerate(pdf.pages, 1):
                    # Extract tables first
                    tables = self._extract_tables(page, page_num)
                    extracted_content["tables"].extend(tables)
                    
                    # Extract text and headings in order
                    content_lines = self._extract_content_in_order(page, page_num)
                    if content_lines:
                        extracted_content["content"].extend(content_lines)
            
            return extracted_content
            
        except Exception as e:
            self.logger.error(f"Error extracting PDF content: {str(e)}")
            raise
    
    def _extract_content_in_order(self, page, page_num: int) -> List[Dict[str, str]]:
        """Extract text and headings in the order they appear in the PDF."""
        try:
            # Extract text while preserving layout
            text = page.extract_text(layout=True)
            
            if not text:
                return []
            
            # Split text into lines
            lines = text.split('\n')
            content_lines = []
            
            for line in lines:
                cleaned_line = line.rstrip()
                
                # Skip empty lines
                if not cleaned_line.strip():
                    continue
                
                # Check if line is a heading based on characteristics
                if self._is_heading(cleaned_line):
                    content_lines.append({
                        "type": "heading",
                        "content": cleaned_line.strip()
                    })
                else:
                    # Only add non-empty text lines
                    if cleaned_line.strip():
                        content_lines.append({
                            "type": "text",
                            "content": cleaned_line
                        })
            
            return content_lines
            
        except Exception as e:
            self.logger.error(f"Error extracting content from page {page_num}: {str(e)}")
            return []
    
    def _is_heading(self, line: str) -> bool:
        """Determine if a line is a heading based on content characteristics."""
        line = line.strip()
        
        if not line:
            return False
        
        # Check for common heading patterns
        heading_indicators = [
            # All caps and short
            line.isupper() and len(line.split()) <= 6,
            # Title case and short
            line.istitle() and len(line.split()) <= 8,
            # Starts with numbers (1., 1.1, etc.)
            bool(re.match(r'^\d+\.(\d+\.)*\s+', line)),
            # Contains common heading words
            any(word in line.lower() for word in ['summary', 'analysis', 'outlook', 'performance', 'report']),
            # Short line with colons or specific patterns
            len(line.split()) <= 5 and any(char in line for char in [':', '—', '–']),
            # Ends with certain patterns that suggest headings
            line.endswith(('Summary', 'Analysis', 'Report', 'Outlook', 'Performance', 'Quarter'))
        ]
        
        return any(heading_indicators)
    
    def _extract_tables(self, page, page_num: int) -> List[Dict]:
        """Extract tables from a PDF page."""
        tables = []
        
        try:
            # Extract tables using pdfplumber
            detected_tables = page.find_tables()
            
            for i, table in enumerate(detected_tables):
                table_data = table.extract()
                
                if not table_data or len(table_data) == 0:
                    continue
                
                # Clean table data
                cleaned_data = []
                for row in table_data:
                    if row and any(cell for cell in row if cell):  # Skip empty rows
                        cleaned_row = []
                        for cell in row:
                            if cell is None:
                                cleaned_row.append("")
                            else:
                                # Clean cell content but preserve spacing
                                cleaned_cell = str(cell).strip()
                                cleaned_row.append(cleaned_cell)
                        cleaned_data.append(cleaned_row)
                
                if cleaned_data:
                    # Determine if first row is header
                    has_header = self._detect_header(cleaned_data)
                    
                    table_structure = {
                        "data": cleaned_data,
                        "header": cleaned_data[0] if has_header else None,
                        "rows": cleaned_data[1:] if has_header else cleaned_data
                    }
                    
                    tables.append(table_structure)
            
        except Exception as e:
            self.logger.error(f"Error extracting tables from page {page_num}: {str(e)}")
        
        return tables
    
    def _detect_header(self, data: List[List[str]]) -> bool:
        """Simple header detection."""
        if not data or len(data) < 2:
            return False
        
        first_row = data[0]
        
        # Check if first row contains mostly text (not numbers)
        text_cells = sum(1 for cell in first_row if cell and not self._is_numeric(cell))
        total_cells = len([cell for cell in first_row if cell])
        
        return total_cells > 0 and (text_cells / total_cells) > 0.5
    
    def _is_numeric(self, value: str) -> bool:
        """Check if a string represents a numeric value."""
        try:
            # Remove common formatting characters
            cleaned = value.replace(',', '').replace('$', '').replace('%', '')
            float(cleaned)
            return True
        except (ValueError, AttributeError):
            return False
    
    def save_to_json(self, content: Dict[str, Any], output_path: str) -> None:
        """Save extracted content to JSON file."""
        try:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(content, f, indent=2, ensure_ascii=False)
            
            print(f"Content saved to: {output_path}")
            
        except Exception as e:
            self.logger.error(f"Error saving JSON: {str(e)}")
            raise


def main():
    """Main function with command-line interface."""
    parser = argparse.ArgumentParser(
        description="Extract text and tables from PDF files with clean JSON output",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python simple_pdf_extractor.py document.pdf
  python simple_pdf_extractor.py document.pdf -o clean_output.json
        """
    )
    
    parser.add_argument(
        'pdf_path',
        help='Path to the PDF file to extract content from'
    )
    
    parser.add_argument(
        '-o', '--output',
        help='Output JSON file path (default: <pdf_name>_simple.json)'
    )
    
    args = parser.parse_args()
    
    try:
        # Initialize extractor
        extractor = SimplePDFExtractor()
        
        # Extract content
        print(f"Extracting content from: {args.pdf_path}")
        content = extractor.extract_pdf_content(args.pdf_path)
        
        # Determine output path
        if args.output:
            output_path = args.output
        else:
            pdf_name = Path(args.pdf_path).stem
            output_path = f"{pdf_name}_simple.json"
        
        # Save to JSON
        extractor.save_to_json(content, output_path)
        
        # Print summary
        text_count = sum(1 for item in content['content'] if item['type'] == 'text')
        heading_count = sum(1 for item in content['content'] if item['type'] == 'heading')
        print(f"✓ Extracted {text_count} text lines")
        print(f"✓ Extracted {heading_count} headings")
        print(f"✓ Extracted {len(content['tables'])} tables")
        print(f"✓ Content ordered as: text, heading, text, text, heading, text...")
        print(f"✓ Output saved to: {output_path}")
        
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()