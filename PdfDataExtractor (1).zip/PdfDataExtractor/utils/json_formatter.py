"""
JSON formatting utilities for PDF content extraction.
Handles structuring and formatting of extracted content.
"""

import json
import logging
from typing import Dict, Any, List
from datetime import datetime

from config.extraction_config import ExtractionConfig


class JSONFormatter:
    """Formats extracted PDF content into structured JSON."""
    
    def __init__(self, config: ExtractionConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    def format_content(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format extracted content into structured JSON.
        
        Args:
            content: Raw extracted content
            
        Returns:
            Formatted JSON-ready content
        """
        try:
            formatted_content = {
                "document_metadata": self._format_document_metadata(content),
                "extraction_summary": self._create_extraction_summary(content),
                "content": {
                    "text_blocks": self._format_text_blocks(content.get("text_content", [])),
                    "headings": self._format_headings(content.get("headings", [])),
                    "tables": self._format_tables(content.get("tables", []))
                },
                "document_structure": self._create_document_structure(content),
                "extraction_metadata": self._format_extraction_metadata(content)
            }
            
            return formatted_content
            
        except Exception as e:
            self.logger.error(f"Error formatting content: {str(e)}")
            raise
    
    def _format_document_metadata(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Format document metadata."""
        doc_info = content.get("document_info", {})
        
        return {
            "filename": doc_info.get("filename", ""),
            "source_path": doc_info.get("path", ""),
            "total_pages": doc_info.get("total_pages", 0),
            "processed_at": datetime.now().isoformat(),
            "file_size_bytes": self._get_file_size(doc_info.get("path", "")),
            "extraction_version": content.get("extraction_metadata", {}).get("config_version", "1.0")
        }
    
    def _create_extraction_summary(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Create extraction summary statistics."""
        text_blocks = content.get("text_content", [])
        headings = content.get("headings", [])
        tables = content.get("tables", [])
        
        return {
            "total_text_blocks": len(text_blocks),
            "total_headings": len(headings),
            "total_tables": len(tables),
            "total_words": sum(block.get("word_count", 0) for block in text_blocks),
            "total_characters": sum(len(block.get("text", "")) for block in text_blocks),
            "heading_levels": self._get_heading_level_distribution(headings),
            "pages_with_tables": len(set(table.get("page", 0) for table in tables)),
            "largest_table": self._get_largest_table_info(tables)
        }
    
    def _format_text_blocks(self, text_blocks: List[Dict]) -> List[Dict]:
        """Format text blocks for JSON output."""
        formatted_blocks = []
        
        for i, block in enumerate(text_blocks):
            formatted_block = {
                "id": f"text_block_{i + 1}",
                "text": block.get("text", ""),
                "page": block.get("page", 0),
                "position": {
                    "bbox": block.get("bbox", []),
                    "x": block.get("bbox", [0])[0] if block.get("bbox") else 0,
                    "y": block.get("bbox", [0, 0])[1] if block.get("bbox") else 0
                },
                "formatting": {
                    "font_name": block.get("font_name", ""),
                    "font_size": block.get("font_size", 0),
                    "word_count": block.get("word_count", 0),
                    "character_count": len(block.get("text", ""))
                },
                "classification": {
                    "type": block.get("type", "text"),
                    "confidence": block.get("confidence", 1.0)
                }
            }
            
            formatted_blocks.append(formatted_block)
        
        return formatted_blocks
    
    def _format_headings(self, headings: List[Dict]) -> List[Dict]:
        """Format headings for JSON output."""
        formatted_headings = []
        
        for i, heading in enumerate(headings):
            formatted_heading = {
                "id": f"heading_{i + 1}",
                "text": heading.get("text", ""),
                "level": heading.get("heading_level", 1),
                "page": heading.get("page", 0),
                "position": {
                    "bbox": heading.get("bbox", []),
                    "x": heading.get("bbox", [0])[0] if heading.get("bbox") else 0,
                    "y": heading.get("bbox", [0, 0])[1] if heading.get("bbox") else 0
                },
                "formatting": {
                    "font_name": heading.get("font_name", ""),
                    "font_size": heading.get("font_size", 0),
                    "word_count": heading.get("word_count", 0)
                },
                "classification": {
                    "confidence": heading.get("confidence", 1.0),
                    "detection_method": self._get_detection_method(heading)
                }
            }
            
            formatted_headings.append(formatted_heading)
        
        return formatted_headings
    
    def _format_tables(self, tables: List[Dict]) -> List[Dict]:
        """Format tables for JSON output."""
        formatted_tables = []
        
        for table in tables:
            formatted_table = {
                "id": table.get("table_id", ""),
                "page": table.get("page", 0),
                "table_number": table.get("table_number", 0),
                "position": {
                    "bbox": table.get("bbox", []),
                    "x": table.get("bbox", [0])[0] if table.get("bbox") else 0,
                    "y": table.get("bbox", [0, 0])[1] if table.get("bbox") else 0
                },
                "structure": {
                    "rows": table.get("rows", 0),
                    "columns": table.get("columns", 0),
                    "has_header": table.get("has_header", False),
                    "cell_count": table.get("metadata", {}).get("cell_count", 0),
                    "empty_cells": table.get("metadata", {}).get("empty_cells", 0)
                },
                "header": table.get("header", []),
                "data": table.get("body", []),
                "raw_data": table.get("data", []),
                "extraction_metadata": {
                    "confidence": table.get("metadata", {}).get("extraction_confidence", 0.0),
                    "is_fallback_detection": table.get("is_fallback_detection", False),
                    "detection_method": "pdfplumber"
                }
            }
            
            formatted_tables.append(formatted_table)
        
        return formatted_tables
    
    def _create_document_structure(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Create document structure overview."""
        headings = content.get("headings", [])
        tables = content.get("tables", [])
        
        # Group content by page
        pages = {}
        all_content = []
        
        # Add headings
        for heading in headings:
            page = heading.get("page", 0)
            all_content.append({
                "type": "heading",
                "page": page,
                "y_position": heading.get("bbox", [0, 0, 0, 0])[1],
                "content": heading
            })
        
        # Add tables
        for table in tables:
            page = table.get("page", 0)
            all_content.append({
                "type": "table",
                "page": page,
                "y_position": table.get("bbox", [0, 0, 0, 0])[1],
                "content": table
            })
        
        # Sort by page and position
        all_content.sort(key=lambda x: (x["page"], -x["y_position"]))  # Negative y for top-to-bottom
        
        # Group by page
        for item in all_content:
            page = item["page"]
            if page not in pages:
                pages[page] = []
            pages[page].append({
                "type": item["type"],
                "id": item["content"].get("table_id" if item["type"] == "table" else "heading_id", ""),
                "content_preview": self._get_content_preview(item["content"], item["type"])
            })
        
        return {
            "total_pages": content.get("document_info", {}).get("total_pages", 0),
            "pages": pages,
            "document_outline": self._create_document_outline(headings)
        }
    
    def _create_document_outline(self, headings: List[Dict]) -> List[Dict]:
        """Create hierarchical document outline from headings."""
        outline = []
        
        for heading in headings:
            outline_item = {
                "text": heading.get("text", ""),
                "level": heading.get("heading_level", 1),
                "page": heading.get("page", 0),
                "id": f"heading_{len(outline) + 1}"
            }
            outline.append(outline_item)
        
        return outline
    
    def _format_extraction_metadata(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Format extraction metadata."""
        original_metadata = content.get("extraction_metadata", {})
        
        return {
            "extraction_method": original_metadata.get("extraction_method", "pdfplumber"),
            "config_version": original_metadata.get("config_version", "1.0"),
            "processing_time": datetime.now().isoformat(),
            "features_used": {
                "table_detection": True,
                "heading_detection": True,
                "font_analysis": True,
                "structure_analysis": True
            },
            "quality_metrics": {
                "text_extraction_confidence": 0.95,  # High confidence for pdfplumber
                "table_extraction_confidence": self._calculate_average_table_confidence(content.get("tables", [])),
                "heading_detection_confidence": self._calculate_average_heading_confidence(content.get("headings", []))
            }
        }
    
    def _get_file_size(self, path: str) -> int:
        """Get file size in bytes."""
        try:
            from pathlib import Path
            return Path(path).stat().st_size
        except Exception:
            return 0
    
    def _get_heading_level_distribution(self, headings: List[Dict]) -> Dict[str, int]:
        """Get distribution of heading levels."""
        levels = {}
        for heading in headings:
            level = heading.get("heading_level", 1)
            levels[f"level_{level}"] = levels.get(f"level_{level}", 0) + 1
        return levels
    
    def _get_largest_table_info(self, tables: List[Dict]) -> Dict[str, Any]:
        """Get information about the largest table."""
        if not tables:
            return {}
        
        largest_table = max(tables, key=lambda t: t.get("rows", 0) * t.get("columns", 0))
        return {
            "id": largest_table.get("table_id", ""),
            "page": largest_table.get("page", 0),
            "rows": largest_table.get("rows", 0),
            "columns": largest_table.get("columns", 0),
            "cell_count": largest_table.get("metadata", {}).get("cell_count", 0)
        }
    
    def _get_detection_method(self, heading: Dict) -> str:
        """Determine how the heading was detected."""
        font_size = heading.get("font_size", 0)
        font_name = heading.get("font_name", "").lower()
        
        if "bold" in font_name:
            return "font_weight"
        elif font_size > 12:
            return "font_size"
        else:
            return "content_analysis"
    
    def _get_content_preview(self, content: Dict, content_type: str) -> str:
        """Get a preview of the content."""
        if content_type == "heading":
            text = content.get("text", "")
            return text[:100] + "..." if len(text) > 100 else text
        elif content_type == "table":
            rows = content.get("rows", 0)
            cols = content.get("columns", 0)
            return f"Table ({rows}x{cols})"
        return ""
    
    def _calculate_average_table_confidence(self, tables: List[Dict]) -> float:
        """Calculate average confidence for table extraction."""
        if not tables:
            return 0.0
        
        confidences = [table.get("metadata", {}).get("extraction_confidence", 0.0) for table in tables]
        return sum(confidences) / len(confidences)
    
    def _calculate_average_heading_confidence(self, headings: List[Dict]) -> float:
        """Calculate average confidence for heading detection."""
        if not headings:
            return 0.0
        
        confidences = [heading.get("confidence", 1.0) for heading in headings]
        return sum(confidences) / len(confidences)
