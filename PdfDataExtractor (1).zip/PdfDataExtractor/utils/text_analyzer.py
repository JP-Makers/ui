"""
Text analysis utilities for PDF content extraction.
Handles text block identification, heading detection, and font analysis.
"""

import logging
from typing import List, Dict, Any, Tuple, Optional
from collections import defaultdict, Counter
import re

from config.extraction_config import ExtractionConfig


class TextAnalyzer:
    """Analyzes PDF text content for structure and formatting."""
    
    def __init__(self, config: ExtractionConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    def analyze_text(self, chars: List[Dict], page_num: int, table_bboxes: List[Tuple] = None) -> Tuple[List[Dict], List[Dict]]:
        """
        Analyze text characters to identify text blocks and headings.
        
        Args:
            chars: List of character objects from pdfplumber
            page_num: Current page number
            table_bboxes: Bounding boxes of tables to exclude from text
            
        Returns:
            Tuple of (text_blocks, headings)
        """
        if not chars:
            return [], []
        
        # Filter out characters that are part of tables
        filtered_chars = self._filter_table_chars(chars, table_bboxes or [])
        
        if not filtered_chars:
            return [], []
        
        # Group characters into text blocks
        text_blocks = self._group_text_blocks(filtered_chars)
        
        # Analyze font properties for heading detection
        font_stats = self._analyze_font_properties(filtered_chars)
        
        # Classify text blocks as headings or regular text
        classified_blocks = self._classify_text_blocks(text_blocks, font_stats, page_num)
        
        # Separate headings from regular text
        headings = [block for block in classified_blocks if block['type'] == 'heading']
        text_content = [block for block in classified_blocks if block['type'] == 'text']
        
        return text_content, headings
    
    def _filter_table_chars(self, chars: List[Dict], table_bboxes: List[Tuple]) -> List[Dict]:
        """Filter out characters that are part of tables."""
        if not table_bboxes:
            return chars
        
        filtered_chars = []
        for char in chars:
            char_in_table = False
            char_x = char.get('x0', 0)
            char_y = char.get('y0', 0)
            
            for bbox in table_bboxes:
                x0, y0, x1, y1 = bbox
                if x0 <= char_x <= x1 and y0 <= char_y <= y1:
                    char_in_table = True
                    break
            
            if not char_in_table:
                filtered_chars.append(char)
        
        return filtered_chars
    
    def _group_text_blocks(self, chars: List[Dict]) -> List[Dict]:
        """Group characters into coherent text blocks."""
        if not chars:
            return []
        
        # Sort characters by position (top to bottom, left to right)
        sorted_chars = sorted(chars, key=lambda c: (-c.get('y0', 0), c.get('x0', 0)))
        
        text_blocks = []
        current_block = []
        current_line_y = None
        line_height_threshold = self.config.line_height_threshold
        
        for char in sorted_chars:
            char_y = char.get('y0', 0)
            char_text = char.get('text', '')
            
            # Skip whitespace-only characters
            if not char_text or char_text.isspace():
                continue
            
            # Start new block if this is a new line with significant vertical gap
            if current_line_y is not None and abs(char_y - current_line_y) > line_height_threshold:
                if current_block:
                    text_blocks.append(self._create_text_block(current_block))
                    current_block = []
            
            current_block.append(char)
            current_line_y = char_y
        
        # Add the last block
        if current_block:
            text_blocks.append(self._create_text_block(current_block))
        
        return text_blocks
    
    def _create_text_block(self, chars: List[Dict]) -> Dict:
        """Create a text block from a list of characters."""
        if not chars:
            return {}
        
        # Combine text
        text = ''.join(char.get('text', '') for char in chars)
        text = re.sub(r'\s+', ' ', text).strip()  # Normalize whitespace
        
        # Calculate bounding box
        x0 = min(char.get('x0', 0) for char in chars)
        y0 = min(char.get('y0', 0) for char in chars)
        x1 = max(char.get('x1', 0) for char in chars)
        y1 = max(char.get('y1', 0) for char in chars)
        
        # Get font properties (use most common values)
        font_names = [char.get('fontname', '') for char in chars if char.get('fontname')]
        font_sizes = [char.get('size', 0) for char in chars if char.get('size')]
        
        font_name = Counter(font_names).most_common(1)[0][0] if font_names else ''
        font_size = sum(font_sizes) / len(font_sizes) if font_sizes else 0
        
        return {
            'text': text,
            'bbox': (x0, y0, x1, y1),
            'font_name': font_name,
            'font_size': font_size,
            'char_count': len(chars),
            'word_count': len(text.split()) if text else 0
        }
    
    def _analyze_font_properties(self, chars: List[Dict]) -> Dict:
        """Analyze font properties across all characters."""
        font_sizes = []
        font_names = []
        
        for char in chars:
            if char.get('size'):
                font_sizes.append(char['size'])
            if char.get('fontname'):
                font_names.append(char['fontname'])
        
        if not font_sizes:
            return {}
        
        # Calculate font statistics
        font_size_counter = Counter(font_sizes)
        font_name_counter = Counter(font_names)
        
        # Determine base font size (most common)
        base_font_size = font_size_counter.most_common(1)[0][0]
        
        # Calculate thresholds for heading detection
        heading_size_threshold = base_font_size * self.config.heading_size_multiplier
        
        return {
            'base_font_size': base_font_size,
            'heading_size_threshold': heading_size_threshold,
            'font_size_distribution': dict(font_size_counter),
            'font_name_distribution': dict(font_name_counter),
            'common_font_name': font_name_counter.most_common(1)[0][0] if font_names else ''
        }
    
    def _classify_text_blocks(self, text_blocks: List[Dict], font_stats: Dict, page_num: int) -> List[Dict]:
        """Classify text blocks as headings or regular text."""
        classified_blocks = []
        
        for block in text_blocks:
            block_type = self._determine_block_type(block, font_stats)
            
            # Add metadata
            block['type'] = block_type
            block['page'] = page_num
            block['confidence'] = self._calculate_confidence(block, font_stats)
            
            # Add heading-specific metadata
            if block_type == 'heading':
                block['heading_level'] = self._determine_heading_level(block, font_stats)
            
            classified_blocks.append(block)
        
        return classified_blocks
    
    def _determine_block_type(self, block: Dict, font_stats: Dict) -> str:
        """Determine if a text block is a heading or regular text."""
        if not font_stats:
            return 'text'
        
        font_size = block.get('font_size', 0)
        font_name = block.get('font_name', '')
        text = block.get('text', '')
        word_count = block.get('word_count', 0)
        
        # Size-based detection
        heading_threshold = font_stats.get('heading_size_threshold', 0)
        if font_size > heading_threshold:
            return 'heading'
        
        # Font name-based detection (bold, italic indicators)
        if any(keyword in font_name.lower() for keyword in ['bold', 'black', 'heavy', 'demi']):
            return 'heading'
        
        # Content-based detection
        if self._is_heading_content(text, word_count):
            return 'heading'
        
        return 'text'
    
    def _is_heading_content(self, text: str, word_count: int) -> bool:
        """Determine if text content looks like a heading."""
        if not text:
            return False
        
        # Short text with specific patterns
        if word_count <= self.config.max_heading_words:
            # All caps
            if text.isupper() and len(text) > 1:
                return True
            
            # Starts with number (1., 1.1, etc.)
            if re.match(r'^\d+\.(\d+\.)*\s+', text):
                return True
            
            # Title case
            if text.istitle() and word_count >= 2:
                return True
        
        return False
    
    def _determine_heading_level(self, block: Dict, font_stats: Dict) -> int:
        """Determine the heading level (1-6) based on font size."""
        font_size = block.get('font_size', 0)
        base_size = font_stats.get('base_font_size', 12)
        
        # Calculate level based on font size relative to base
        size_ratio = font_size / base_size if base_size > 0 else 1
        
        if size_ratio >= 2.0:
            return 1
        elif size_ratio >= 1.5:
            return 2
        elif size_ratio >= 1.3:
            return 3
        elif size_ratio >= 1.2:
            return 4
        elif size_ratio >= 1.1:
            return 5
        else:
            return 6
    
    def _calculate_confidence(self, block: Dict, font_stats: Dict) -> float:
        """Calculate confidence score for the classification."""
        if block['type'] == 'text':
            return 1.0  # High confidence for regular text
        
        # For headings, calculate based on multiple factors
        confidence = 0.0
        factors = 0
        
        # Font size factor
        font_size = block.get('font_size', 0)
        heading_threshold = font_stats.get('heading_size_threshold', 0)
        if font_size > heading_threshold:
            confidence += 0.4
            factors += 1
        
        # Font name factor
        font_name = block.get('font_name', '').lower()
        if any(keyword in font_name for keyword in ['bold', 'black', 'heavy']):
            confidence += 0.3
            factors += 1
        
        # Content factor
        text = block.get('text', '')
        word_count = block.get('word_count', 0)
        if self._is_heading_content(text, word_count):
            confidence += 0.3
            factors += 1
        
        return confidence if factors > 0 else 0.5
