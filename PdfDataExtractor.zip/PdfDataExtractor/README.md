# PDF Content Extractor

A high-accuracy Python script that extracts text, headings, and tables from PDF files and outputs structured JSON format. Built with advanced parsing capabilities using pdfplumber for superior accuracy.

## Features

- **High-accuracy extraction**: Uses pdfplumber for precise text and table extraction
- **Advanced table detection**: Preserves exact table structure with rows, columns, and cell content
- **Intelligent heading detection**: Analyzes font properties to identify headings with confidence scoring
- **Structured JSON output**: Well-organized JSON format preserving document structure
- **Complex layout support**: Handles multi-column text, rotated content, and complex PDF layouts
- **Command-line interface**: Easy to use with file path arguments
- **Robust error handling**: Comprehensive logging and error management
- **Configurable settings**: Customizable extraction parameters

## Installation

### Dependencies

Install the required Python packages:

```bash
pip install pdfplumber pandas
