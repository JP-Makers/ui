"""
Configuration settings for PDF extraction.
Contains all configurable parameters for the extraction process.
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any


class ExtractionConfig:
    """Configuration class for PDF extraction settings."""
    
    def __init__(self):
        self.version = "1.0"
        self.log_level = "INFO"
        
        # Text analysis settings
        self.line_height_threshold = 5  # Pixels
        self.heading_size_multiplier = 1.2  # Multiplier for base font size
        self.max_heading_words = 15  # Maximum words in a heading
        
        # Table detection settings
        self.table_settings = {
            "vertical_strategy": "lines",
            "horizontal_strategy": "lines",
            "min_words_vertical": 3,
            "min_words_horizontal": 1,
            "intersection_tolerance": 3,
            "text_tolerance": 3,
            "text_x_tolerance": 3,
            "text_y_tolerance": 3
        }
        
        # Fallback options
        self.use_fallback_table_detection = True
        
        # Output settings
        self.output_format = "json"
        self.pretty_print = True
        self.include_metadata = True
        
        # Performance settings
        self.max_pages_per_batch = 10
        self.enable_caching = False
        
        # Quality settings
        self.min_table_confidence = 0.3
        self.min_heading_confidence = 0.5
        
        # Font analysis settings
        self.font_size_tolerance = 0.5
        self.font_name_similarity_threshold = 0.8
        
        # Content filtering
        self.filter_empty_content = True
        self.min_text_length = 5
        self.max_text_length = 10000
        
        # Logging settings
        self.log_file = "pdf_extraction.log"
        self.log_rotation = True
        self.log_max_size = 10 * 1024 * 1024  # 10MB
        
    def load_from_file(self, config_path: str) -> None:
        """Load configuration from JSON file."""
        try:
            config_file = Path(config_path)
            if not config_file.exists():
                raise FileNotFoundError(f"Configuration file not found: {config_path}")
            
            with open(config_file, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
            
            self._update_from_dict(config_data)
            
        except Exception as e:
            logging.error(f"Error loading configuration: {str(e)}")
            raise
    
    def save_to_file(self, config_path: str) -> None:
        """Save current configuration to JSON file."""
        try:
            config_file = Path(config_path)
            config_file.parent.mkdir(parents=True, exist_ok=True)
            
            config_data = self.to_dict()
            
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            
        except Exception as e:
            logging.error(f"Error saving configuration: {str(e)}")
            raise
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "version": self.version,
            "log_level": self.log_level,
            "text_analysis": {
                "line_height_threshold": self.line_height_threshold,
                "heading_size_multiplier": self.heading_size_multiplier,
                "max_heading_words": self.max_heading_words
            },
            "table_detection": {
                "table_settings": self.table_settings,
                "use_fallback_table_detection": self.use_fallback_table_detection,
                "min_table_confidence": self.min_table_confidence
            },
            "output": {
                "output_format": self.output_format,
                "pretty_print": self.pretty_print,
                "include_metadata": self.include_metadata
            },
            "performance": {
                "max_pages_per_batch": self.max_pages_per_batch,
                "enable_caching": self.enable_caching
            },
            "quality": {
                "min_heading_confidence": self.min_heading_confidence,
                "font_size_tolerance": self.font_size_tolerance,
                "font_name_similarity_threshold": self.font_name_similarity_threshold
            },
            "content_filtering": {
                "filter_empty_content": self.filter_empty_content,
                "min_text_length": self.min_text_length,
                "max_text_length": self.max_text_length
            },
            "logging": {
                "log_file": self.log_file,
                "log_rotation": self.log_rotation,
                "log_max_size": self.log_max_size
            }
        }
    
    def _update_from_dict(self, config_data: Dict[str, Any]) -> None:
        """Update configuration from dictionary."""
        # Update version
        self.version = config_data.get("version", self.version)
        self.log_level = config_data.get("log_level", self.log_level)
        
        # Update text analysis settings
        text_analysis = config_data.get("text_analysis", {})
        self.line_height_threshold = text_analysis.get("line_height_threshold", self.line_height_threshold)
        self.heading_size_multiplier = text_analysis.get("heading_size_multiplier", self.heading_size_multiplier)
        self.max_heading_words = text_analysis.get("max_heading_words", self.max_heading_words)
        
        # Update table detection settings
        table_detection = config_data.get("table_detection", {})
        self.table_settings.update(table_detection.get("table_settings", {}))
        self.use_fallback_table_detection = table_detection.get("use_fallback_table_detection", self.use_fallback_table_detection)
        self.min_table_confidence = table_detection.get("min_table_confidence", self.min_table_confidence)
        
        # Update output settings
        output = config_data.get("output", {})
        self.output_format = output.get("output_format", self.output_format)
        self.pretty_print = output.get("pretty_print", self.pretty_print)
        self.include_metadata = output.get("include_metadata", self.include_metadata)
        
        # Update performance settings
        performance = config_data.get("performance", {})
        self.max_pages_per_batch = performance.get("max_pages_per_batch", self.max_pages_per_batch)
        self.enable_caching = performance.get("enable_caching", self.enable_caching)
        
        # Update quality settings
        quality = config_data.get("quality", {})
        self.min_heading_confidence = quality.get("min_heading_confidence", self.min_heading_confidence)
        self.font_size_tolerance = quality.get("font_size_tolerance", self.font_size_tolerance)
        self.font_name_similarity_threshold = quality.get("font_name_similarity_threshold", self.font_name_similarity_threshold)
        
        # Update content filtering
        content_filtering = config_data.get("content_filtering", {})
        self.filter_empty_content = content_filtering.get("filter_empty_content", self.filter_empty_content)
        self.min_text_length = content_filtering.get("min_text_length", self.min_text_length)
        self.max_text_length = content_filtering.get("max_text_length", self.max_text_length)
        
        # Update logging settings
        logging_config = config_data.get("logging", {})
        self.log_file = logging_config.get("log_file", self.log_file)
        self.log_rotation = logging_config.get("log_rotation", self.log_rotation)
        self.log_max_size = logging_config.get("log_max_size", self.log_max_size)
    
    def validate(self) -> bool:
        """Validate configuration settings."""
        try:
            # Validate numeric values
            if self.line_height_threshold < 0:
                raise ValueError("line_height_threshold must be non-negative")
            
            if self.heading_size_multiplier <= 0:
                raise ValueError("heading_size_multiplier must be positive")
            
            if self.max_heading_words <= 0:
                raise ValueError("max_heading_words must be positive")
            
            if not 0 <= self.min_table_confidence <= 1:
                raise ValueError("min_table_confidence must be between 0 and 1")
            
            if not 0 <= self.min_heading_confidence <= 1:
                raise ValueError("min_heading_confidence must be between 0 and 1")
            
            # Validate string values
            if self.log_level not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
                raise ValueError("Invalid log_level")
            
            if self.output_format not in ["json", "xml", "yaml"]:
                raise ValueError("Invalid output_format")
            
            return True
            
        except Exception as e:
            logging.error(f"Configuration validation failed: {str(e)}")
            return False
    
    def get_table_settings_for_page(self, page_num: int) -> Dict[str, Any]:
        """Get table detection settings for a specific page."""
        # Could be customized per page if needed
        return self.table_settings.copy()
    
    def get_text_analysis_settings(self) -> Dict[str, Any]:
        """Get text analysis settings."""
        return {
            "line_height_threshold": self.line_height_threshold,
            "heading_size_multiplier": self.heading_size_multiplier,
            "max_heading_words": self.max_heading_words,
            "font_size_tolerance": self.font_size_tolerance,
            "font_name_similarity_threshold": self.font_name_similarity_threshold
        }
