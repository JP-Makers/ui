#!/usr/bin/env python3
"""
Demo script showing PDF content extraction capabilities.
"""

import json
from pdf_extractor import PDFExtractor
from config.extraction_config import ExtractionConfig

def main():
    print("=== PDF Content Extractor Demo ===\n")
    
    # Initialize extractor with default config
    config = ExtractionConfig()
    extractor = PDFExtractor(config)
    
    # Extract content from the sample PDF
    print("1. Extracting content from sample_document.pdf...")
    content = extractor.extract_pdf_content("sample_document.pdf")
    
    print(f"   ✓ Found {len(content['text_content'])} text blocks")
    print(f"   ✓ Found {len(content['headings'])} headings")
    print(f"   ✓ Found {len(content['tables'])} tables")
    
    # Save to JSON
    print("\n2. Saving structured JSON output...")
    extractor.save_to_json(content, "demo_output.json")
    print("   ✓ JSON saved to demo_output.json")
    
    # Show sample extracted data
    print("\n3. Sample extracted data:")
    print("\n--- HEADINGS ---")
    for i, heading in enumerate(content['headings'][:5]):
        print(f"   {i+1}. Level {heading.get('heading_level', 'N/A')}: {heading['text'][:50]}...")
    
    print("\n--- TABLES ---")
    for i, table in enumerate(content['tables']):
        print(f"   Table {i+1}: {table['rows']} rows × {table['columns']} columns")
        if table.get('header'):
            print(f"   Header: {table['header']}")
        if table.get('data'):
            print(f"   First row: {table['data'][0] if table['data'] else 'N/A'}")
    
    print("\n--- TEXT BLOCKS ---")
    for i, text_block in enumerate(content['text_content'][:3]):
        print(f"   {i+1}. {text_block['text'][:60]}...")
    
    print(f"\n4. Complete JSON structure includes:")
    print("   • Document metadata (filename, pages, processing time)")
    print("   • Extraction summary (counts, statistics)")
    print("   • Text blocks with positioning and formatting")
    print("   • Headings with levels and confidence scores")
    print("   • Tables with preserved structure and data")
    print("   • Document outline and page structure")
    print("   • Quality metrics and extraction metadata")
    
    print("\n=== Demo Complete ===")
    print("Check demo_output.json for the complete structured data!")

if __name__ == "__main__":
    main()