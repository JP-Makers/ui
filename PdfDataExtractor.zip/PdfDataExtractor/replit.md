# PDF Content Extractor

## Overview

This is a high-accuracy Python application that extracts text, headings, and tables from PDF files and outputs structured JSON format. The application uses pdfplumber for precise extraction and features advanced parsing capabilities including intelligent heading detection, table structure preservation, and multi-column text handling.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular architecture with clear separation of concerns:

- **Core Extraction Engine**: The main `PDFExtractor` class orchestrates the extraction process
- **Utility Modules**: Specialized processors for text analysis, table processing, and JSON formatting
- **Configuration Management**: Centralized configuration system for extraction parameters
- **Command-Line Interface**: Simple CLI for file processing

The architecture is designed for extensibility, allowing easy addition of new extraction features or output formats.

## Key Components

### 1. Main Extractor (`pdf_extractor.py`)
- **Purpose**: Central coordinator for PDF processing
- **Key Features**: 
  - Handles file input/output operations
  - Manages the extraction pipeline
  - Provides comprehensive logging and error handling
  - Integrates all utility modules

### 2. Text Analysis (`utils/text_analyzer.py`)
- **Purpose**: Analyzes text structure and identifies headings
- **Key Features**:
  - Font property analysis for heading detection
  - Text block grouping and classification
  - Multi-column text handling
  - Table text filtering to avoid duplication

### 3. Table Processing (`utils/table_processor.py`)
- **Purpose**: Extracts and structures table data
- **Key Features**:
  - Advanced table detection with fallback mechanisms
  - Preserves exact table structure (rows, columns, cells)
  - Handles complex table layouts
  - Confidence scoring for table quality

### 4. JSON Formatting (`utils/json_formatter.py`)
- **Purpose**: Structures extracted content into JSON format
- **Key Features**:
  - Document metadata management
  - Extraction summary generation
  - Structured content organization
  - Configurable output formatting

### 5. Configuration System (`config/extraction_config.py`)
- **Purpose**: Centralized configuration management
- **Key Features**:
  - Text analysis parameters (heading detection thresholds)
  - Table detection settings with fallback options
  - Output formatting preferences
  - Performance and quality settings

## Data Flow

1. **Input Processing**: PDF file path provided via command line
2. **Page-by-Page Analysis**: Each page processed individually for scalability
3. **Content Extraction**: 
   - Text characters extracted and analyzed
   - Tables detected and structured
   - Headings identified through font analysis
4. **Content Integration**: All extracted content combined and cross-referenced
5. **JSON Generation**: Structured output created with metadata and summaries
6. **Output**: Final JSON written to file or stdout

## External Dependencies

### Core Dependencies
- **pdfplumber**: Primary PDF parsing library chosen for high accuracy
- **pandas**: Table data manipulation and structuring
- **Python Standard Library**: argparse, json, logging, pathlib, typing

### Dependency Rationale
- **pdfplumber over PyPDF2/PDFMiner**: Superior table detection and text positioning accuracy
- **pandas**: Robust data structure handling for complex tables
- **Minimal dependencies**: Keeps the application lightweight and reduces compatibility issues

## Deployment Strategy

### Development Environment
- Python 3.7+ compatibility
- Virtual environment recommended
- Simple pip install for dependencies

### Production Considerations
- **Logging**: Comprehensive logging to both console and file
- **Error Handling**: Robust error management with graceful degradation
- **Memory Management**: Page-by-page processing to handle large PDFs
- **Configuration**: Externalized settings for easy tuning

### Scalability Features
- **Batch Processing**: Configurable page batching for memory efficiency
- **Caching**: Optional caching system for repeated processing
- **Fallback Mechanisms**: Alternative extraction methods when primary methods fail

The application is designed to be easily deployable as a standalone script or integrated into larger document processing pipelines.