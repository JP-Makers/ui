import json

with open('sample_document_extracted.json', 'r') as f:
    data = json.load(f)
    
print('=== TABLE DATA ===')
for i, table in enumerate(data['content']['tables']):
    print(f'Table {i+1}:')
    print(f'  ID: {table["id"]}')
    print(f'  Page: {table["page"]}')
    print(f'  Structure: {table["structure"]["rows"]} rows × {table["structure"]["columns"]} columns')
    print(f'  Header: {table["header"]}')
    print(f'  Data (first 3 rows):')
    for j, row in enumerate(table['data'][:3]):
        print(f'    Row {j+1}: {row}')
    print()