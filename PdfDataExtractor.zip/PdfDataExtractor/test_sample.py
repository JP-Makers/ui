#!/usr/bin/env python3
"""
Test script to demonstrate PDF extraction functionality.
Creates sample content and shows how the extractor works.
"""

from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import os

def create_sample_pdf():
    """Create a sample PDF with text, headings, and tables for testing."""
    doc = SimpleDocTemplate("sample_document.pdf", pagesize=letter)
    styles = getSampleStyleSheet()
    
    # Create custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        spaceAfter=30,
        textColor=colors.black,
        fontName='Helvetica-Bold'
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        spaceAfter=12,
        textColor=colors.black,
        fontName='Helvetica-Bold'
    )
    
    # Build content
    content = []
    
    # Title
    content.append(Paragraph("Annual Sales Report 2024", title_style))
    content.append(Spacer(1, 12))
    
    # Introduction section
    content.append(Paragraph("Executive Summary", heading_style))
    content.append(Paragraph(
        "This report presents the annual sales performance for the year 2024. "
        "The company achieved significant growth across all product categories, "
        "with total revenue reaching $2.5 million, representing a 15% increase "
        "from the previous year. Key highlights include strong performance in "
        "digital products and expansion into new markets.",
        styles['Normal']
    ))
    content.append(Spacer(1, 12))
    
    # Sales Data section
    content.append(Paragraph("Sales Performance by Quarter", heading_style))
    content.append(Paragraph(
        "The following table shows quarterly sales data broken down by product category:",
        styles['Normal']
    ))
    content.append(Spacer(1, 12))
    
    # Create sales table
    sales_data = [
        ['Quarter', 'Software', 'Hardware', 'Services', 'Total'],
        ['Q1 2024', '$450,000', '$320,000', '$180,000', '$950,000'],
        ['Q2 2024', '$520,000', '$380,000', '$200,000', '$1,100,000'],
        ['Q3 2024', '$480,000', '$340,000', '$220,000', '$1,040,000'],
        ['Q4 2024', '$550,000', '$420,000', '$260,000', '$1,230,000'],
        ['Total', '$2,000,000', '$1,460,000', '$860,000', '$4,320,000']
    ]
    
    sales_table = Table(sales_data, colWidths=[1.2*inch, 1.2*inch, 1.2*inch, 1.2*inch, 1.2*inch])
    sales_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -2), colors.beige),
        ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
        ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    content.append(sales_table)
    content.append(Spacer(1, 20))
    
    # Regional Analysis section
    content.append(Paragraph("Regional Performance Analysis", heading_style))
    content.append(Paragraph(
        "Our expansion into new geographic markets has shown promising results. "
        "The North American market continues to be our strongest performer, "
        "while European and Asian markets showed steady growth throughout the year.",
        styles['Normal']
    ))
    content.append(Spacer(1, 12))
    
    # Regional data table
    regional_data = [
        ['Region', 'Revenue', 'Growth Rate', 'Market Share'],
        ['North America', '$2,160,000', '12%', '50%'],
        ['Europe', '$1,296,000', '18%', '30%'],
        ['Asia Pacific', '$864,000', '25%', '20%']
    ]
    
    regional_table = Table(regional_data, colWidths=[1.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
    regional_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.lightblue),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    content.append(regional_table)
    content.append(Spacer(1, 20))
    
    # Conclusion section
    content.append(Paragraph("Future Outlook", heading_style))
    content.append(Paragraph(
        "Based on current trends and market analysis, we project continued growth "
        "in the coming year. Key initiatives include product innovation, "
        "market expansion, and strategic partnerships. We anticipate achieving "
        "our target of $5 million in revenue by the end of 2025.",
        styles['Normal']
    ))
    
    # Build the PDF
    doc.build(content)
    print("Sample PDF created: sample_document.pdf")

if __name__ == "__main__":
    create_sample_pdf()