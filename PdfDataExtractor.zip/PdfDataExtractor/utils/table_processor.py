"""
Table processing utilities for PDF content extraction.
Handles table detection, structure analysis, and data extraction.
"""

import logging
from typing import List, Dict, Any, Tuple, Optional
import pandas as pd

from config.extraction_config import ExtractionConfig


class TableProcessor:
    """Processes tables from PDF content with high accuracy."""
    
    def __init__(self, config: ExtractionConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    def extract_tables(self, page, page_num: int) -> List[Dict]:
        """
        Extract all tables from a PDF page.
        
        Args:
            page: pdfplumber page object
            page_num: Current page number
            
        Returns:
            List of table dictionaries
        """
        tables = []
        
        try:
            # Extract tables using pdfplumber's table detection
            detected_tables = page.find_tables(table_settings=self.config.table_settings)
            
            for i, table in enumerate(detected_tables):
                table_data = self._process_table(table, page_num, i + 1)
                if table_data:
                    tables.append(table_data)
            
            # If no tables found with default settings, try with relaxed settings
            if not tables and self.config.use_fallback_table_detection:
                relaxed_settings = self._get_relaxed_table_settings()
                detected_tables = page.find_tables(table_settings=relaxed_settings)
                
                for i, table in enumerate(detected_tables):
                    table_data = self._process_table(table, page_num, i + 1, is_fallback=True)
                    if table_data:
                        tables.append(table_data)
            
        except Exception as e:
            self.logger.error(f"Error extracting tables from page {page_num}: {str(e)}")
        
        return tables
    
    def _process_table(self, table, page_num: int, table_num: int, is_fallback: bool = False) -> Optional[Dict]:
        """Process a single table and extract its data."""
        try:
            # Extract table data
            table_data = table.extract()
            
            if not table_data or len(table_data) == 0:
                return None
            
            # Clean and process table data
            processed_data = self._clean_table_data(table_data)
            
            if not processed_data:
                return None
            
            # Get table metadata
            bbox = table.bbox
            
            # Determine if first row is header
            has_header = self._detect_table_header(processed_data)
            
            # Create table structure
            table_structure = {
                'table_id': f"page_{page_num}_table_{table_num}",
                'page': page_num,
                'table_number': table_num,
                'bbox': bbox,
                'rows': len(processed_data),
                'columns': len(processed_data[0]) if processed_data else 0,
                'has_header': has_header,
                'is_fallback_detection': is_fallback,
                'data': processed_data,
                'header': processed_data[0] if has_header and processed_data else [],
                'body': processed_data[1:] if has_header and len(processed_data) > 1 else processed_data,
                'metadata': {
                    'extraction_confidence': self._calculate_table_confidence(processed_data, bbox),
                    'cell_count': sum(len(row) for row in processed_data),
                    'empty_cells': self._count_empty_cells(processed_data)
                }
            }
            
            return table_structure
            
        except Exception as e:
            self.logger.error(f"Error processing table {table_num} on page {page_num}: {str(e)}")
            return None
    
    def _clean_table_data(self, raw_data: List[List[str]]) -> List[List[str]]:
        """Clean and normalize table data."""
        if not raw_data:
            return []
        
        cleaned_data = []
        
        for row in raw_data:
            if not row:
                continue
            
            # Clean cells
            cleaned_row = []
            for cell in row:
                if cell is None:
                    cleaned_cell = ""
                else:
                    # Convert to string and clean
                    cleaned_cell = str(cell).strip()
                    # Replace multiple whitespace with single space
                    cleaned_cell = ' '.join(cleaned_cell.split())
                
                cleaned_row.append(cleaned_cell)
            
            # Only add non-empty rows
            if any(cell.strip() for cell in cleaned_row):
                cleaned_data.append(cleaned_row)
        
        # Ensure all rows have the same number of columns
        if cleaned_data:
            max_cols = max(len(row) for row in cleaned_data)
            for row in cleaned_data:
                while len(row) < max_cols:
                    row.append("")
        
        return cleaned_data
    
    def _detect_table_header(self, data: List[List[str]]) -> bool:
        """Detect if the first row is a header."""
        if not data or len(data) < 2:
            return False
        
        first_row = data[0]
        
        # Check if first row has different characteristics from subsequent rows
        header_indicators = 0
        total_checks = 0
        
        # Check 1: Non-empty cells in first row
        non_empty_first = sum(1 for cell in first_row if cell.strip())
        if non_empty_first > 0:
            header_indicators += 1
        total_checks += 1
        
        # Check 2: Different content pattern (text vs numbers)
        if len(data) > 1:
            first_row_numeric = sum(1 for cell in first_row if self._is_numeric(cell))
            second_row_numeric = sum(1 for cell in data[1] if self._is_numeric(cell))
            
            if first_row_numeric < second_row_numeric:
                header_indicators += 1
            total_checks += 1
        
        # Check 3: Capitalization pattern
        capitalized_cells = sum(1 for cell in first_row if cell.strip() and cell.strip()[0].isupper())
        if capitalized_cells > len(first_row) * 0.5:
            header_indicators += 1
        total_checks += 1
        
        return header_indicators >= total_checks * 0.6
    
    def _is_numeric(self, value: str) -> bool:
        """Check if a string represents a numeric value."""
        try:
            float(value.replace(',', '').replace('$', '').replace('%', ''))
            return True
        except (ValueError, AttributeError):
            return False
    
    def _calculate_table_confidence(self, data: List[List[str]], bbox: Tuple) -> float:
        """Calculate confidence score for table extraction."""
        if not data:
            return 0.0
        
        confidence = 0.0
        
        # Factor 1: Table size (larger tables are more likely to be real tables)
        row_count = len(data)
        col_count = len(data[0]) if data else 0
        
        if row_count >= 3 and col_count >= 2:
            confidence += 0.3
        elif row_count >= 2 and col_count >= 2:
            confidence += 0.2
        
        # Factor 2: Data consistency (consistent column count)
        if data:
            col_counts = [len(row) for row in data]
            if len(set(col_counts)) == 1:  # All rows have same column count
                confidence += 0.2
        
        # Factor 3: Content quality (not too many empty cells)
        total_cells = sum(len(row) for row in data)
        empty_cells = self._count_empty_cells(data)
        if total_cells > 0:
            fill_ratio = 1 - (empty_cells / total_cells)
            confidence += 0.3 * fill_ratio
        
        # Factor 4: Bounding box reasonableness
        if bbox:
            x0, y0, x1, y1 = bbox
            width = x1 - x0
            height = y1 - y0
            if width > 100 and height > 50:  # Reasonable table size
                confidence += 0.2
        
        return min(confidence, 1.0)
    
    def _count_empty_cells(self, data: List[List[str]]) -> int:
        """Count empty or whitespace-only cells."""
        empty_count = 0
        for row in data:
            for cell in row:
                if not cell or not cell.strip():
                    empty_count += 1
        return empty_count
    
    def _get_relaxed_table_settings(self) -> Dict:
        """Get relaxed table detection settings for fallback."""
        return {
            "vertical_strategy": "text",
            "horizontal_strategy": "text",
            "min_words_vertical": 1,
            "min_words_horizontal": 1,
            "intersection_tolerance": 5,
            "text_tolerance": 5,
            "text_x_tolerance": 5,
            "text_y_tolerance": 5
        }
    
    def get_table_bboxes(self, page) -> List[Tuple]:
        """Get bounding boxes of all tables on a page."""
        bboxes = []
        
        try:
            tables = page.find_tables(table_settings=self.config.table_settings)
            for table in tables:
                if table.bbox:
                    bboxes.append(table.bbox)
        except Exception as e:
            self.logger.error(f"Error getting table bboxes: {str(e)}")
        
        return bboxes
