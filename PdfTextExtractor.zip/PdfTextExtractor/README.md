# PDF OCR Library

A Python library for extracting text from PDF files with intelligent text box detection and line-by-line combination. Perfect for documents where text boxes contain numbers or labels that should be combined with adjacent normal text.

## Features

- **Smart Text Box Detection**: Automatically identifies text boxes containing numbers, labels, or short phrases
- **Line-by-Line Combination**: Combines text box content with normal text on the same line
- **Accurate Layout Analysis**: Preserves spatial relationships between text elements
- **Simple API**: Easy-to-use interface for quick PDF text extraction
- **No Dependencies on Heavy OCR**: Uses PyMuPDF and pdfplumber for fast, accurate text extraction

## Example

Input PDF line: `1.1` (text box) + `Turn left` (normal text)  
Output: `1.1 Turn left`

## Installation

```bash
pip install PyMuPDF pdfplumber
```

## Quick Start

### Simple Usage

```python
from pdf_ocr import SimplePDFOCR

# Create OCR instance
ocr = SimplePDFOCR()

# Extract all text from PDF
text = ocr.extract_text("document.pdf")
print(text)

# Extract specific pages
text = ocr.extract_text("document.pdf", [1, 3, 5])
print(text)
```

### Command Line Usage

```bash
# Extract all pages
python pdf_ocr.py document.pdf

# Extract specific pages
python pdf_ocr.py document.pdf 1,3,5-10

# Run example
python example_usage.py your_document.pdf
```

## API Reference

### SimplePDFOCR Class

#### Constructor
```python
SimplePDFOCR(min_font_size=6.0)
```
- `min_font_size`: Minimum font size to consider (default: 6.0)

#### Methods

##### extract_text(pdf_path, page_numbers=None)
Extracts text from PDF file.

**Parameters:**
- `pdf_path` (str): Path to PDF file
- `page_numbers` (List[int], optional): List of page numbers (1-based), None for all pages

**Returns:**
- `str`: Extracted text with text boxes combined line by line

**Example:**
```python
# Extract all pages
text = ocr.extract_text("document.pdf")

# Extract pages 1, 2, and 5
text = ocr.extract_text("document.pdf", [1, 2, 5])
```

## How It Works

1. **Text Extraction**: Uses both PyMuPDF and pdfplumber to extract text elements with position information
2. **Text Box Detection**: Identifies text boxes based on:
   - Size (small elements < 100x30 pixels)
   - Content patterns (pure numbers, numbered items like "1.1")
   - Text length (very short text ≤ 3 characters)
3. **Line Grouping**: Groups text elements into lines based on vertical position
4. **Smart Combination**: Combines text boxes with normal text on the same line, maintaining reading order

## Examples of Text Box Detection

The library automatically detects these as text boxes:
- `1.1`, `2.3`, `10.5` (numbered items)
- `A`, `B`, `C` (single letters)
- `123` (pure numbers)
- Small graphical elements

## File Structure

- `pdf_ocr.py` - Main library with SimplePDFOCR class
- `example_usage.py` - Example usage and demonstration
- `text_element.py` - Data structures for text elements
- `pdf_extractor.py` - Advanced PDF extraction (full version)
- `layout_analyzer.py` - Advanced layout analysis
- `text_processor.py` - Advanced text processing
- `main.py` - Command line interface for full version

## Requirements

- Python 3.7+
- PyMuPDF (fitz)
- pdfplumber

## Use Cases

- **Technical Documents**: Manuals with numbered steps and instructions
- **Forms**: Documents with labels and input fields
- **Educational Materials**: Textbooks with numbered exercises
- **Legal Documents**: Contracts with numbered clauses
- **Any PDF**: Where text boxes contain important contextual information

## Performance

- Fast extraction using optimized PDF libraries
- No image processing overhead
- Handles large documents efficiently
- Memory-efficient processing

## Error Handling

The library provides clear error messages for common issues:
- Invalid PDF files
- Missing files
- Corrupted documents
- Access permission errors

## Contributing

1. Fork the repository
2. Create your feature branch
3. Add tests for new functionality
4. Submit a pull request

## License

This project is open source and available under the MIT License.