
#!/usr/bin/env python3
"""
Main entry point for PDF OCR Library demonstration
"""

import sys
import os
from pathlib import Path

# Add the pdf_ocr_lib directory to Python path
sys.path.insert(0, str(Path(__file__).parent / "pdf_ocr_lib"))

from pdf_ocr.core import SimplePDFOCR

def main():
    """Main function to demonstrate PDF OCR functionality"""
    
    print("PDF OCR Library - Main Demo")
    print("=" * 40)
    
    # Check if a PDF file was provided as argument
    if len(sys.argv) > 1:
        pdf_file = sys.argv[1]
    else:
        # Use the test document if no file provided
        pdf_file = "pdf_ocr_lib/test_document.pdf"
        
        # Create test document if it doesn't exist
        if not os.path.exists(pdf_file):
            print("Creating test document...")
            try:
                # Import create_test_pdf from examples
                examples_path = Path(__file__).parent / "pdf_ocr_lib" / "examples"
                sys.path.insert(0, str(examples_path))
                from create_test_pdf import create_test_pdf
                create_test_pdf(pdf_file)
                print(f"✓ Created {pdf_file}")
            except Exception as e:
                print(f"Error creating test document: {e}")
                return
    
    # Check if file exists
    if not os.path.exists(pdf_file):
        print(f"Error: PDF file '{pdf_file}' not found")
        print("Usage: python main.py [pdf_file]")
        return
    
    print(f"Processing: {pdf_file}")
    print("-" * 40)
    
    try:
        # Initialize OCR
        ocr = SimplePDFOCR(min_font_size=6.0)
        
        # Extract text
        text = ocr.extract_text(pdf_file)
        
        # Display results
        print("EXTRACTED TEXT:")
        print("-" * 30)
        print(text)
        print("-" * 30)
        
        # Show statistics
        lines = text.split('\n')
        words = text.split()
        chars = len(text)
        
        print(f"\nStatistics:")
        print(f"  File: {pdf_file}")
        print(f"  Lines: {len(lines)}")
        print(f"  Words: {len(words)}")
        print(f"  Characters: {chars}")
        
        # Show usage examples
        print(f"\nOther ways to use this library:")
        print(f"  python -m pdf_ocr_lib.pdf_ocr {pdf_file}")
        print(f"  python pdf_ocr_lib/examples/basic_usage.py {pdf_file}")
        
    except Exception as e:
        print(f"Error processing PDF: {e}")
        print("Make sure the PDF file is valid and accessible")

if __name__ == "__main__":
    main()
