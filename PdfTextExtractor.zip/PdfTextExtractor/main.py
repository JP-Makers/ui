
#!/usr/bin/env python3
"""
Main entry point for PDF OCR Library demonstration
"""

import sys
import os
import json
import csv
import argparse
from pathlib import Path
import xml.etree.ElementTree as ET

# Add the pdf_ocr_lib directory to Python path
sys.path.insert(0, str(Path(__file__).parent / "pdf_ocr_lib"))

from pdf_ocr.core import SimplePDFOCR

def export_to_json(data):
    """Export data to JSON format"""
    return json.dumps(data, indent=2, ensure_ascii=False)

def export_to_csv(data):
    """Export data to CSV format"""
    import io
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow(['Line Number', 'Content', 'Word Count', 'Character Count'])
    
    # Write data rows
    for line in data["extracted_text"]["lines"]:
        writer.writerow([
            line["line_number"],
            line["content"],
            line["word_count"],
            line["character_count"]
        ])
    
    return output.getvalue()

def export_to_xml(data):
    """Export data to XML format"""
    root = ET.Element("pdf_extraction")
    
    # File info
    file_info = ET.SubElement(root, "file_info")
    ET.SubElement(file_info, "filename").text = data["file_info"]["filename"]
    ET.SubElement(file_info, "total_lines").text = str(data["file_info"]["total_lines"])
    ET.SubElement(file_info, "total_words").text = str(data["file_info"]["total_words"])
    ET.SubElement(file_info, "total_characters").text = str(data["file_info"]["total_characters"])
    
    # Extracted text
    extracted_text = ET.SubElement(root, "extracted_text")
    lines_elem = ET.SubElement(extracted_text, "lines")
    
    for line in data["extracted_text"]["lines"]:
        line_elem = ET.SubElement(lines_elem, "line")
        ET.SubElement(line_elem, "line_number").text = str(line["line_number"])
        ET.SubElement(line_elem, "content").text = line["content"]
        ET.SubElement(line_elem, "word_count").text = str(line["word_count"])
        ET.SubElement(line_elem, "character_count").text = str(line["character_count"])
    
    return ET.tostring(root, encoding='unicode', xml_declaration=True)

def export_to_text(data):
    """Export data to plain text format"""
    output = []
    output.append(f"PDF Extraction Results")
    output.append(f"=" * 50)
    output.append(f"File: {data['file_info']['filename']}")
    output.append(f"Total Lines: {data['file_info']['total_lines']}")
    output.append(f"Total Words: {data['file_info']['total_words']}")
    output.append(f"Total Characters: {data['file_info']['total_characters']}")
    output.append(f"=" * 50)
    output.append("")
    
    for line in data["extracted_text"]["lines"]:
        output.append(f"Line {line['line_number']:3d}: {line['content']}")
    
    return "\n".join(output)

def export_to_continuous(data):
    """Export data to continuous text format showing combined text boxes"""
    output = []
    output.append(f"PDF Text Extraction - Continuous Format")
    output.append(f"File: {data['file_info']['filename']}")
    output.append(f"=" * 60)
    output.append("")
    
    for line in data["extracted_text"]["lines"]:
        content = line['content']
        if content.strip() and not content.startswith("==="):
            output.append(content)
    
    return "\n".join(output)

def main():
    """Main function to demonstrate PDF OCR functionality with export formats"""
    
    parser = argparse.ArgumentParser(description='PDF OCR Library with Export Formats')
    parser.add_argument('pdf_file', nargs='?', default='pdf_ocr_lib/test_document.pdf',
                        help='PDF file to process')
    parser.add_argument('--format', '-f', choices=['json', 'csv', 'xml', 'txt', 'continuous'], 
                        default='json', help='Export format (default: json)')
    parser.add_argument('--output', '-o', help='Output file (default: stdout)')
    parser.add_argument('--show-textboxes', action='store_true',
                        help='Show which parts are detected as text boxes')
    
    args = parser.parse_args()
    
    print("PDF OCR Library - Main Demo")
    print("=" * 40)
    
    pdf_file = args.pdf_file
    
    # Create test document if it doesn't exist
    if not os.path.exists(pdf_file):
        print("Creating test document...")
        try:
            # Import create_test_pdf from examples
            examples_path = Path(__file__).parent / "pdf_ocr_lib" / "examples"
            sys.path.insert(0, str(examples_path))
            from create_test_pdf import create_test_pdf
            create_test_pdf(pdf_file)
            print(f"✓ Created {pdf_file}")
        except Exception as e:
            print(f"Error creating test document: {e}")
            return
    
    # Check if file exists
    if not os.path.exists(pdf_file):
        print(f"Error: PDF file '{pdf_file}' not found")
        return
    
    print(f"Processing: {pdf_file}")
    print(f"Export format: {args.format}")
    print("-" * 40)
    
    try:
        # Initialize OCR
        ocr = SimplePDFOCR(min_font_size=6.0)
        
        # Extract text
        text = ocr.extract_text(pdf_file)
        
        # Prepare data structure
        lines = text.split('\n')
        words = text.split()
        chars = len(text)
        
        # Create data structure
        data = {
            "file_info": {
                "filename": pdf_file,
                "total_lines": len(lines),
                "total_words": len(words),
                "total_characters": chars
            },
            "extracted_text": {
                "lines": []
            },
            "statistics": {
                "line_count": len(lines),
                "word_count": len(words),
                "character_count": chars
            }
        }
        
        # Add each line as a separate entry
        for i, line in enumerate(lines, 1):
            line_data = {
                "line_number": i,
                "content": line,
                "word_count": len(line.split()) if line.strip() else 0,
                "character_count": len(line)
            }
            data["extracted_text"]["lines"].append(line_data)
        
        # Export in requested format
        if args.format == 'json':
            output = export_to_json(data)
        elif args.format == 'csv':
            output = export_to_csv(data)
        elif args.format == 'xml':
            output = export_to_xml(data)
        elif args.format == 'txt':
            output = export_to_text(data)
        elif args.format == 'continuous':
            output = export_to_continuous(data)
            
        # Show text box detection if requested
        if args.show_textboxes:
            print("TEXT BOX DETECTION ANALYSIS:")
            print("-" * 40)
            ocr_debug = SimplePDFOCR(min_font_size=6.0)
            # This would require modifying the core to return detection info
            print("Text boxes are automatically detected based on:")
            print("- Size: Small elements (< 100x30 pixels)")
            print("- Content: Numbers, short text (≤3 chars), numbered items")
            print("- Examples: '4.1', 'A', '123', 'R1'")
            print("-" * 40)
            print("")
        
        # Write to file or stdout
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(output)
            print(f"✓ Exported to {args.output}")
        else:
            print(output)
        
    except Exception as e:
        print(f"Error processing PDF: {e}")
        print("Make sure the PDF file is valid and accessible")

if __name__ == "__main__":
    main()
