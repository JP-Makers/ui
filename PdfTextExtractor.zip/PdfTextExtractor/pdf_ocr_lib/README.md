# PDF OCR Library

A Python library for extracting text from PDF files with intelligent text box detection and line-by-line combination. Perfect for documents where text boxes contain numbers or labels that should be combined with adjacent normal text.

## Features

- **Smart Text Box Detection**: Automatically identifies text boxes containing numbers, labels, or short phrases
- **Line-by-Line Combination**: Combines text box content with normal text on the same line
- **Accurate Layout Analysis**: Preserves spatial relationships between text elements
- **Simple API**: Easy-to-use interface for quick PDF text extraction
- **Command Line Interface**: Use directly from terminal
- **No Dependencies on Heavy OCR**: Uses PyMuPDF and pdfplumber for fast, accurate text extraction

## Example

Input PDF line: `1.1` (text box) + `Turn left` (normal text)  
Output: `1.1 Turn left`

## Installation

### From Source

```bash
cd pdf_ocr_lib
pip install .
```

### For Development

```bash
cd pdf_ocr_lib
pip install -e .[dev]
```

## Quick Start

### Python Library Usage

```python
from pdf_ocr import SimplePDFOCR

# Create OCR instance
ocr = SimplePDFOCR()

# Extract all text from PDF
text = ocr.extract_text("document.pdf")
print(text)

# Extract specific pages
text = ocr.extract_text("document.pdf", [1, 3, 5])
print(text)
```

### Command Line Usage

```bash
# Extract all pages
python -m pdf_ocr document.pdf

# Extract specific pages
python -m pdf_ocr document.pdf 1,3,5-10

# Or use the installed command
pdf-ocr document.pdf
```

## Library Structure

```
pdf_ocr_lib/
├── pdf_ocr/                 # Main library package
│   ├── __init__.py         # Package initialization
│   ├── core.py             # Core OCR functionality
│   ├── utils.py            # Utility functions
│   ├── cli.py              # Command line interface
│   ├── version.py          # Version information
│   └── __main__.py         # Module entry point
├── examples/               # Usage examples
│   ├── basic_usage.py      # Basic usage examples
│   └── create_test_pdf.py  # Test PDF creation
├── tests/                  # Test suite
│   ├── __init__.py
│   └── test_core.py        # Core functionality tests
├── docs/                   # Documentation
├── setup.py               # Setup script
├── pyproject.toml         # Modern Python packaging
└── README.md              # This file
```

## API Reference

### SimplePDFOCR Class

#### Constructor
```python
SimplePDFOCR(min_font_size=6.0)
```
- `min_font_size`: Minimum font size to consider (default: 6.0)

#### Methods

##### extract_text(pdf_path, page_numbers=None)
Extracts text from PDF file.

**Parameters:**
- `pdf_path` (str): Path to PDF file
- `page_numbers` (List[int], optional): List of page numbers (1-based), None for all pages

**Returns:**
- `str`: Extracted text with text boxes combined line by line

**Raises:**
- `Exception`: If PDF extraction fails

**Example:**
```python
# Extract all pages
text = ocr.extract_text("document.pdf")

# Extract pages 1, 2, and 5
text = ocr.extract_text("document.pdf", [1, 2, 5])
```

### Utility Functions

#### validate_pdf_file(file_path)
Validates that a file exists and is a valid PDF.

#### get_pdf_info(file_path)
Returns information about a PDF file (page count, metadata, etc.).

#### format_file_size(size_bytes)
Formats file size in human-readable format.

#### estimate_reading_time(text, wpm=200)
Estimates reading time for extracted text.

## How It Works

1. **Text Extraction**: Uses both PyMuPDF and pdfplumber to extract text elements with position information
2. **Text Box Detection**: Identifies text boxes based on:
   - Size (small elements < 100x30 pixels)
   - Content patterns (pure numbers, numbered items like "1.1")
   - Text length (very short text ≤ 3 characters)
3. **Line Grouping**: Groups text elements into lines based on vertical position
4. **Smart Combination**: Combines text boxes with normal text on the same line, maintaining reading order

## Examples of Text Box Detection

The library automatically detects these as text boxes:
- `1.1`, `2.3`, `10.5` (numbered items)
- `A`, `B`, `C` (single letters)
- `123` (pure numbers)
- Small graphical elements

## Development

### Running Tests

```bash
cd pdf_ocr_lib
python tests/test_core.py
```

### Running Examples

```bash
cd pdf_ocr_lib

# Create a test PDF
python examples/create_test_pdf.py

# Run basic usage example
python examples/basic_usage.py test_document.pdf
```

### Code Style

The project uses Black for code formatting:

```bash
black pdf_ocr/
```

## Requirements

- Python 3.7+
- PyMuPDF (fitz)
- pdfplumber

## Use Cases

- **Technical Documents**: Manuals with numbered steps and instructions
- **Forms**: Documents with labels and input fields
- **Educational Materials**: Textbooks with numbered exercises
- **Legal Documents**: Contracts with numbered clauses
- **Any PDF**: Where text boxes contain important contextual information

## Performance

- Fast extraction using optimized PDF libraries
- No image processing overhead
- Handles large documents efficiently
- Memory-efficient processing

## Error Handling

The library provides clear error messages for common issues:
- Invalid PDF files
- Missing files
- Corrupted documents
- Access permission errors

## License

This project is open source and available under the MIT License.

## Contributing

1. Fork the repository
2. Create your feature branch
3. Add tests for new functionality
4. Submit a pull request