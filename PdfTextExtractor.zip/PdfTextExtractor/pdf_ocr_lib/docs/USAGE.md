# PDF OCR Library Usage Guide

## Installation

### From Source
```bash
cd pdf_ocr_lib
pip install .
```

### For Development
```bash
cd pdf_ocr_lib
pip install -e .[dev]
```

## Basic Usage

### Python Library

```python
from pdf_ocr import SimplePDFOCR

# Initialize the OCR
ocr = SimplePDFOCR(min_font_size=6.0)

# Extract all text
text = ocr.extract_text("document.pdf")
print(text)

# Extract specific pages
text = ocr.extract_text("document.pdf", [1, 3, 5])
print(text)
```

### Command Line Interface

```bash
# Extract all pages
python -m pdf_ocr document.pdf

# Extract specific pages
python -m pdf_ocr document.pdf 1,3,5-10

# Using installed command
pdf-ocr document.pdf
```

## API Documentation

### SimplePDFOCR Class

Main class for PDF text extraction with intelligent text box detection.

#### Constructor
```python
SimplePDFOCR(min_font_size=6.0)
```

**Parameters:**
- `min_font_size` (float): Minimum font size to consider for extraction (default: 6.0)

#### Methods

##### extract_text(pdf_path, page_numbers=None)
Extract text from PDF file with text box combination.

**Parameters:**
- `pdf_path` (str): Path to the PDF file
- `page_numbers` (List[int], optional): List of 1-based page numbers to extract. If None, extracts all pages.

**Returns:**
- `str`: Extracted text with text boxes combined with normal text line by line

**Raises:**
- `Exception`: If PDF extraction fails

**Example:**
```python
ocr = SimplePDFOCR()

# Extract all pages
all_text = ocr.extract_text("manual.pdf")

# Extract pages 1, 5, and 10-15
selected_text = ocr.extract_text("manual.pdf", [1, 5] + list(range(10, 16)))
```

## Text Box Detection

The library automatically detects text boxes based on:

1. **Size**: Elements smaller than 100x30 pixels
2. **Content patterns**: 
   - Pure numbers: `123`, `45`
   - Numbered items: `1.1`, `2.3`, `10.5`
   - Short numbered text: `1.1 A`
3. **Text length**: Very short text (≤ 3 characters)

### Examples of Detected Text Boxes
- `1.1` → Detected as text box
- `A` → Detected as text box  
- `123` → Detected as text box
- `Turn left` → Normal text
- `This is a long sentence` → Normal text

## Line Combination Examples

Input PDF content:
```
[Text Box: "1.1"] [Normal: "Turn left at the intersection"]
[Text Box: "2."] [Normal: "Continue straight"]
[Text Box: "A"] [Normal: "Alternative route option"]
```

Library output:
```
1.1 Turn left at the intersection
2. Continue straight
A Alternative route option
```

## Advanced Usage

### Custom Font Size Filtering
```python
# Only extract text with font size 10 or larger
ocr = SimplePDFOCR(min_font_size=10.0)
text = ocr.extract_text("document.pdf")
```

### Page Range Extraction
```python
ocr = SimplePDFOCR()

# Extract first 5 pages
first_pages = ocr.extract_text("doc.pdf", list(range(1, 6)))

# Extract specific pages
selected = ocr.extract_text("doc.pdf", [1, 3, 7, 10])

# Extract page ranges
ranges = list(range(1, 6)) + list(range(20, 31))  # Pages 1-5 and 20-30
text = ocr.extract_text("doc.pdf", ranges)
```

### Error Handling
```python
from pdf_ocr import SimplePDFOCR
from pdf_ocr.utils import validate_pdf_file

pdf_file = "document.pdf"

# Validate file before processing
if not validate_pdf_file(pdf_file):
    print(f"Invalid PDF file: {pdf_file}")
    exit(1)

try:
    ocr = SimplePDFOCR()
    text = ocr.extract_text(pdf_file)
    print(f"Extracted {len(text)} characters")
except Exception as e:
    print(f"Extraction failed: {e}")
```

## Utility Functions

### File Validation
```python
from pdf_ocr.utils import validate_pdf_file

if validate_pdf_file("document.pdf"):
    print("Valid PDF file")
else:
    print("Invalid or inaccessible PDF file")
```

### PDF Information
```python
from pdf_ocr.utils import get_pdf_info

info = get_pdf_info("document.pdf")
print(f"Pages: {info['page_count']}")
print(f"Size: {info['size_formatted']}")
print(f"Title: {info['title']}")
```

### Reading Time Estimation
```python
from pdf_ocr.utils import estimate_reading_time

text = "Your extracted text here..."
reading_info = estimate_reading_time(text)
print(f"Words: {reading_info['words']}")
print(f"Reading time: {reading_info['time']}")
```

## Best Practices

1. **Validate PDFs**: Always validate PDF files before processing
2. **Handle Exceptions**: Wrap extraction calls in try-except blocks
3. **Page Ranges**: Use page ranges for large documents to save memory
4. **Font Size**: Adjust minimum font size to filter out unwanted text
5. **Text Processing**: Post-process extracted text for your specific needs

## Common Use Cases

### Technical Manuals
```python
# Extract numbered instructions
ocr = SimplePDFOCR(min_font_size=8.0)
manual_text = ocr.extract_text("user_manual.pdf")
# Output: "1.1 Connect the device" instead of separate "1.1" and "Connect the device"
```

### Forms and Documents
```python
# Extract form fields with labels
ocr = SimplePDFOCR()
form_text = ocr.extract_text("application_form.pdf")
# Output: "Name: John Smith" instead of separate "Name:" and "John Smith"
```

### Educational Materials
```python
# Extract exercise numbers with questions
ocr = SimplePDFOCR()
homework = ocr.extract_text("math_problems.pdf", [1, 2])  # First 2 pages only
# Output: "1. Solve for x in the equation" instead of separate elements
```

## Troubleshooting

### Common Issues

1. **No text extracted**: Check if PDF contains selectable text (not scanned images)
2. **Poor text combination**: Adjust `min_font_size` parameter
3. **Missing text boxes**: Text boxes might be too large or contain long text
4. **File not found**: Verify file path and permissions

### Debug Tips

```python
# Check PDF validity
from pdf_ocr.utils import validate_pdf_file, get_pdf_info

pdf_file = "problematic.pdf"
if validate_pdf_file(pdf_file):
    info = get_pdf_info(pdf_file)
    print(f"PDF has {info['page_count']} pages")
else:
    print("PDF validation failed")

# Try different font size thresholds
for min_size in [4.0, 6.0, 8.0, 10.0]:
    ocr = SimplePDFOCR(min_font_size=min_size)
    text = ocr.extract_text(pdf_file, [1])  # Test first page only
    print(f"Font size {min_size}: {len(text)} characters")
```