#!/usr/bin/env python3
"""
Basic usage examples for PDF OCR Library
"""

import sys
from pathlib import Path

# Add parent directory to path so we can import the library
sys.path.insert(0, str(Path(__file__).parent.parent))

from pdf_ocr import SimplePDFOCR

def basic_extraction_example():
    """Basic PDF text extraction example"""
    
    if len(sys.argv) < 2:
        print("Please provide a PDF file path")
        print("Example: python basic_usage.py sample.pdf")
        return
    
    pdf_file = sys.argv[1]
    
    print(f"Extracting text from: {pdf_file}")
    print("=" * 50)
    
    try:
        # Initialize OCR
        ocr = SimplePDFOCR(min_font_size=6.0)
        
        # Extract all text
        text = ocr.extract_text(pdf_file)
        
        print("EXTRACTED TEXT:")
        print("-" * 30)
        print(text)
        print("-" * 30)
        
        # Show statistics
        lines = text.split('\n')
        words = text.split()
        chars = len(text)
        
        print(f"\nStatistics:")
        print(f"  Lines: {len(lines)}")
        print(f"  Words: {len(words)}")
        print(f"  Characters: {chars}")
        
    except Exception as e:
        print(f"Error: {e}")

def page_specific_example():
    """Example of extracting specific pages"""
    
    if len(sys.argv) < 2:
        print("Please provide a PDF file path")
        return
    
    pdf_file = sys.argv[1]
    
    try:
        ocr = SimplePDFOCR()
        
        # Extract first page only
        print("Extracting first page only:")
        first_page = ocr.extract_text(pdf_file, [1])
        print(first_page)
        
        # Extract multiple specific pages
        print("\nExtracting pages 1 and 3:")
        specific_pages = ocr.extract_text(pdf_file, [1, 3])
        print(specific_pages)
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    print("PDF OCR Library - Basic Usage Examples")
    print("=" * 40)
    
    basic_extraction_example()
    
    if len(sys.argv) >= 2:
        print("\n" + "=" * 40)
        page_specific_example()