#!/usr/bin/env python3
"""
Create test PDFs for demonstrating the OCR functionality
"""

import fitz  # PyMuPDF
import sys
from pathlib import Path

def create_test_pdf(output_path: str = "test_document.pdf"):
    """Create a test PDF with text boxes and normal text"""
    
    # Create a new PDF document
    doc = fitz.open()
    page = doc.new_page()
    
    # Insert text that simulates text boxes and normal text
    text_content = [
        # Header
        {"text": "Navigation Instructions", "pos": (200, 50), "fontsize": 16},
        
        # Simulate numbered instructions
        {"text": "1.1", "pos": (50, 100), "fontsize": 12},
        {"text": "Turn left at the intersection", "pos": (80, 100), "fontsize": 12},
        
        {"text": "1.2", "pos": (50, 130), "fontsize": 12},
        {"text": "Continue straight for 500 meters", "pos": (80, 130), "fontsize": 12},
        
        {"text": "2.1", "pos": (50, 170), "fontsize": 12},
        {"text": "Enter the building through main entrance", "pos": (80, 170), "fontsize": 12},
        
        {"text": "2.2", "pos": (50, 200), "fontsize": 12},
        {"text": "Take elevator to floor 3", "pos": (80, 200), "fontsize": 12},
        
        # Regular paragraph
        {"text": "These instructions will guide you through the process.", "pos": (50, 250), "fontsize": 11},
        {"text": "Please follow each step carefully for best results.", "pos": (50, 270), "fontsize": 11},
        
        # More numbered items
        {"text": "A", "pos": (50, 320), "fontsize": 12},
        {"text": "First alternative route", "pos": (70, 320), "fontsize": 12},
        
        {"text": "B", "pos": (50, 350), "fontsize": 12},
        {"text": "Second alternative route", "pos": (70, 350), "fontsize": 12},
        
        # Table-like content
        {"text": "Item", "pos": (50, 400), "fontsize": 10},
        {"text": "Quantity", "pos": (150, 400), "fontsize": 10},
        {"text": "Price", "pos": (250, 400), "fontsize": 10},
        
        {"text": "1", "pos": (50, 420), "fontsize": 10},
        {"text": "Apples", "pos": (80, 420), "fontsize": 10},
        {"text": "5", "pos": (150, 420), "fontsize": 10},
        {"text": "$2.50", "pos": (250, 420), "fontsize": 10},
        
        {"text": "2", "pos": (50, 440), "fontsize": 10},
        {"text": "Bananas", "pos": (80, 440), "fontsize": 10},
        {"text": "3", "pos": (150, 440), "fontsize": 10},
        {"text": "$1.80", "pos": (250, 440), "fontsize": 10},
    ]
    
    # Add text to the page
    for item in text_content:
        page.insert_text(item["pos"], item["text"], fontsize=item["fontsize"])
    
    # Save the PDF
    doc.save(output_path)
    doc.close()
    
    return output_path

def main():
    """Create test PDF and show usage"""
    
    output_file = "test_document.pdf"
    if len(sys.argv) > 1:
        output_file = sys.argv[1]
    
    created_file = create_test_pdf(output_file)
    
    print(f"Created {created_file} with sample text")
    print("This PDF contains text boxes (numbers/letters) and normal text")
    print(f"Test extraction with: python -m pdf_ocr {created_file}")
    print(f"Or use examples: python basic_usage.py {created_file}")

if __name__ == "__main__":
    main()