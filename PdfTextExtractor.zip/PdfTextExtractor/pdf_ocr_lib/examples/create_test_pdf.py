
"""
Create a test PDF with text boxes and tables for demonstration
"""

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
import io

def create_test_pdf(filename="test_document.pdf"):
    """Create a test PDF with text boxes, normal text, and tables"""
    
    # Create PDF
    c = canvas.Canvas(filename, pagesize=letter)
    width, height = letter
    
    # Title
    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, height - 50, "Test Document - Text Box + Normal Text Examples")
    
    y_position = height - 100
    
    # Example 1: 4.1 TVS format
    c.setFont("Helvetica", 10)
    
    # Draw text box with border for "4.1"
    text_box_x = 50
    text_box_y = y_position - 20
    text_box_width = 25
    text_box_height = 15
    
    c.rect(text_box_x, text_box_y, text_box_width, text_box_height)
    c.drawString(text_box_x + 3, text_box_y + 3, "4.1")
    
    # Normal text "TVS" right after
    c.drawString(text_box_x + text_box_width + 5, text_box_y + 3, "TVS Diode Protection Circuit")
    
    y_position -= 40
    
    # Example 2: More text box + normal text combinations
    examples = [
        ("5.2", "Resistor Value Calculation"),
        ("6.1", "Capacitor Selection Guide"),
        ("7.3", "Voltage Regulator Configuration"),
        ("8.4", "Oscilloscope Measurement Procedure"),
        ("A", "Alternative Method"),
        ("B", "Secondary Approach"),
        ("1", "Initial Setup Phase"),
        ("2", "Configuration Steps")
    ]
    
    for text_box_content, normal_text in examples:
        # Draw text box
        box_width = len(text_box_content) * 8 + 10
        c.rect(50, y_position - 20, box_width, 15)
        c.drawString(53, y_position - 17, text_box_content)
        
        # Draw normal text
        c.drawString(50 + box_width + 5, y_position - 17, normal_text)
        
        y_position -= 25
    
    # Add a table section
    y_position -= 30
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y_position, "Component Specifications Table:")
    
    y_position -= 30
    
    # Table headers in text boxes
    table_headers = ["Part#", "Type", "Value", "Tolerance", "Package"]
    header_y = y_position
    x_start = 50
    col_widths = [60, 80, 60, 70, 70]
    
    # Draw table headers as text boxes
    current_x = x_start
    for i, header in enumerate(table_headers):
        c.rect(current_x, header_y, col_widths[i], 20)
        c.setFont("Helvetica-Bold", 9)
        c.drawString(current_x + 3, header_y + 6, header)
        current_x += col_widths[i]
    
    # Table data rows
    table_data = [
        ("R1", "Resistor", "10kΩ", "±5%", "0805"),
        ("C1", "Capacitor", "100nF", "±10%", "0603"),
        ("D1", "TVS Diode", "15V", "±5%", "SOD-123"),
        ("U1", "IC Voltage Reg", "3.3V", "±2%", "SOT-23"),
        ("L1", "Inductor", "10µH", "±20%", "1206")
    ]
    
    row_y = header_y - 25
    for row in table_data:
        current_x = x_start
        for i, cell_data in enumerate(row):
            # Draw cell border
            c.rect(current_x, row_y, col_widths[i], 20)
            
            # For first column (Part#), make it look like a text box
            if i == 0:
                c.setFont("Helvetica-Bold", 8)
                # Add small inner border to simulate text box
                c.rect(current_x + 2, row_y + 2, 20, 16)
                c.drawString(current_x + 5, row_y + 8, cell_data)
            else:
                c.setFont("Helvetica", 9)
                c.drawString(current_x + 3, row_y + 6, cell_data)
            
            current_x += col_widths[i]
        row_y -= 25
    
    # Add some continuous numbered instructions
    y_position = row_y - 40
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y_position, "Assembly Instructions:")
    
    y_position -= 30
    instructions = [
        ("1.1", "Prepare the PCB surface by cleaning with isopropyl alcohol"),
        ("1.2", "Apply solder paste using stencil alignment method"),
        ("2.1", "Place TVS diode D1 in correct polarity orientation"),
        ("2.2", "Mount resistor R1 ensuring proper pad contact"),
        ("3.1", "Position capacitor C1 with attention to voltage rating"),
        ("3.2", "Install voltage regulator U1 with thermal considerations"),
        ("4.1", "TVS protection verification using multimeter continuity test"),
        ("4.2", "Final inspection of all component placements before reflow")
    ]
    
    for step_num, instruction in instructions:
        # Text box for step number
        step_width = len(step_num) * 8 + 8
        c.rect(50, y_position - 15, step_width, 12)
        c.setFont("Helvetica-Bold", 8)
        c.drawString(53, y_position - 11, step_num)
        
        # Normal text for instruction
        c.setFont("Helvetica", 10)
        c.drawString(50 + step_width + 5, y_position - 11, instruction)
        
        y_position -= 18
    
    # Save the PDF
    c.save()
    print(f"Created test PDF: {filename}")

if __name__ == "__main__":
    create_test_pdf()
