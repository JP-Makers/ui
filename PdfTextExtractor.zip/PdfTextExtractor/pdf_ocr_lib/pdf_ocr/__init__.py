"""
PDF OCR Library
A Python library for extracting text from PDFs with intelligent text box detection.
"""

from .core import SimplePDFOCR
from .version import __version__

__all__ = ['SimplePDFOCR', '__version__']