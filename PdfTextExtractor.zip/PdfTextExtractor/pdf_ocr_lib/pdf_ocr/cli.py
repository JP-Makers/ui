"""
Command line interface for PDF OCR Library
"""

import sys
from typing import List
from .core import SimplePDFOCR
from .utils import validate_pdf_file

def parse_page_numbers(page_str: str) -> List[int]:
    """
    Parse page numbers string into list of integers
    
    Args:
        page_str: String like "1,3,5-10"
        
    Returns:
        List of page numbers
    """
    pages = []
    for part in page_str.split(','):
        part = part.strip()
        if '-' in part:
            start, end = map(int, part.split('-'))
            pages.extend(range(start, end + 1))
        else:
            pages.append(int(part))
    return sorted(list(set(pages)))

def main():
    """Main command line interface"""
    if len(sys.argv) < 2:
        print("Usage: python -m pdf_ocr <pdf_file> [page_numbers]")
        print("Examples:")
        print("  python -m pdf_ocr document.pdf")
        print("  python -m pdf_ocr document.pdf 1,3,5-10")
        sys.exit(1)
    
    pdf_file = sys.argv[1]
    page_numbers = None
    
    if len(sys.argv) > 2:
        try:
            page_numbers = parse_page_numbers(sys.argv[2])
        except ValueError as e:
            print(f"Error parsing page numbers: {e}", file=sys.stderr)
            sys.exit(1)
    
    # Validate PDF file
    if not validate_pdf_file(pdf_file):
        print(f"Error: Invalid or inaccessible PDF file: {pdf_file}", file=sys.stderr)
        sys.exit(1)
    
    try:
        ocr = SimplePDFOCR()
        text = ocr.extract_text(pdf_file, page_numbers)
        print(text)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()