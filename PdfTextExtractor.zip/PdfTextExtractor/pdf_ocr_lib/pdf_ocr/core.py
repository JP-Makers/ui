"""
Core PDF OCR functionality
Extracts text from PDFs line by line, combining text boxes with normal text
"""

import fitz  # PyMuPDF
import pdfplumber
import re
from typing import List, Optional
from dataclasses import dataclass

@dataclass
class TextItem:
    """Simple text item with position and content"""
    text: str
    x: float
    y: float
    width: float
    height: float
    font_size: float
    is_text_box: bool = False

class SimplePDFOCR:
    """Simple PDF OCR that combines text boxes with normal text line by line"""
    
    def __init__(self, min_font_size: float = 6.0):
        """
        Initialize PDF OCR
        
        Args:
            min_font_size: Minimum font size to consider (default: 6.0)
        """
        self.min_font_size = min_font_size
        self.line_tolerance = 3.0  # pixels tolerance for same line
    
    def extract_text(self, pdf_path: str, page_numbers: Optional[List[int]] = None) -> str:
        """
        Extract text from PDF file
        
        Args:
            pdf_path: Path to PDF file
            page_numbers: List of page numbers to extract (1-based), None for all pages
            
        Returns:
            Extracted text with text boxes combined line by line
            
        Raises:
            Exception: If PDF extraction fails
        """
        try:
            doc = fitz.open(pdf_path)
            all_text = []
            
            with pdfplumber.open(pdf_path) as plumber_doc:
                pages_to_process = page_numbers or list(range(1, len(doc) + 1))
                
                for page_num in pages_to_process:
                    if page_num < 1 or page_num > len(doc):
                        continue
                        
                    # Extract from both libraries
                    fitz_page = doc[page_num - 1]
                    plumber_page = plumber_doc.pages[page_num - 1]
                    
                    page_text = self._extract_page_text(fitz_page, plumber_page, page_num)
                    if page_text.strip():
                        all_text.append(f"=== Page {page_num} ===\n{page_text}")
            
            doc.close()
            return "\n\n".join(all_text)
            
        except Exception as e:
            raise Exception(f"Failed to extract text: {str(e)}")
    
    def _extract_page_text(self, fitz_page, plumber_page, page_num: int) -> str:
        """Extract text from a single page"""
        # Get text items from both sources
        items = []
        
        # PyMuPDF extraction
        text_dict = fitz_page.get_text("dict")
        for block in text_dict.get("blocks", []):
            if "lines" not in block:
                continue
            for line in block["lines"]:
                for span in line["spans"]:
                    if span["text"].strip() and span["size"] >= self.min_font_size:
                        bbox = span["bbox"]
                        is_textbox = self._is_text_box(span["text"], bbox)
                        
                        items.append(TextItem(
                            text=span["text"].strip(),
                            x=bbox[0],
                            y=bbox[1],
                            width=bbox[2] - bbox[0],
                            height=bbox[3] - bbox[1],
                            font_size=span["size"],
                            is_text_box=is_textbox
                        ))
        
        # Group into lines and format
        lines = self._group_into_lines(items)
        return self._format_lines(lines)
    
    def _is_text_box(self, text: str, bbox: tuple) -> bool:
        """Detect if text is likely from a text box (numbers, short phrases)"""
        text = text.strip()
        width = bbox[2] - bbox[0]
        height = bbox[3] - bbox[1]
        
        # Small elements
        if width < 100 and height < 30:
            return True
        
        # Pure numbers or numbered items like "1.1", "2.3"
        if re.match(r'^\d+\.?\d*$', text):
            return True
        
        # Short numbered items
        if re.match(r'^\d+\.?\d*\s*[a-zA-Z]?$', text) and len(text) <= 8:
            return True
        
        # Very short text
        if len(text) <= 3:
            return True
        
        return False
    
    def _group_into_lines(self, items: List[TextItem]) -> List[List[TextItem]]:
        """Group text items into lines based on vertical position"""
        if not items:
            return []
        
        # Sort by vertical position
        sorted_items = sorted(items, key=lambda x: x.y)
        
        lines = []
        current_line = []
        
        for item in sorted_items:
            if not current_line:
                current_line = [item]
            else:
                # Check if item is on the same line
                avg_y = sum(i.y for i in current_line) / len(current_line)
                if abs(item.y - avg_y) <= self.line_tolerance:
                    current_line.append(item)
                else:
                    # Sort current line by x position and add to lines
                    current_line.sort(key=lambda x: x.x)
                    lines.append(current_line)
                    current_line = [item]
        
        # Add last line
        if current_line:
            current_line.sort(key=lambda x: x.x)
            lines.append(current_line)
        
        return lines
    
    def _format_lines(self, lines: List[List[TextItem]]) -> str:
        """Format lines, combining text boxes with normal text"""
        formatted_lines = []
        
        for line in lines:
            if not line:
                continue
            
            # Separate text boxes from normal text
            text_boxes = [item for item in line if item.is_text_box]
            normal_text = [item for item in line if not item.is_text_box]
            
            # Combine intelligently
            if text_boxes and normal_text:
                # Sort all by x position
                all_items = sorted(line, key=lambda x: x.x)
                line_text = " ".join(item.text for item in all_items)
            else:
                # Just normal formatting
                line_text = " ".join(item.text for item in line)
            
            # Clean up spacing
            line_text = re.sub(r'\s+', ' ', line_text).strip()
            
            if line_text:
                formatted_lines.append(line_text)
        
        return "\n".join(formatted_lines)