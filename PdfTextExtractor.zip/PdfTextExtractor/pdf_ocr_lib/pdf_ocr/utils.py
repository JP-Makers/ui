"""
Utility functions for PDF text extraction
"""

import os
from pathlib import Path
from typing import Optional
import fitz

def validate_pdf_file(file_path: str) -> bool:
    """
    Validate that the file exists and is a PDF
    
    Args:
        file_path: Path to the PDF file
        
    Returns:
        True if valid PDF file, False otherwise
    """
    try:
        path = Path(file_path)
        
        # Check if file exists
        if not path.exists():
            return False
        
        # Check if it's a file (not directory)
        if not path.is_file():
            return False
        
        # Check file extension
        if path.suffix.lower() != '.pdf':
            return False
        
        # Check if file is readable
        if not os.access(path, os.R_OK):
            return False
        
        # Try to open the file to check if it's a valid PDF
        try:
            doc = fitz.open(str(path))
            page_count = len(doc)
            doc.close()
            
            if page_count == 0:
                return False
                
        except Exception:
            return False
        
        return True
        
    except Exception:
        return False

def get_pdf_info(file_path: str) -> dict:
    """
    Get basic information about the PDF file
    
    Args:
        file_path: Path to the PDF file
        
    Returns:
        Dictionary with PDF information or error details
    """
    try:
        path = Path(file_path)
        stat = path.stat()
        
        # Get PDF specific info
        doc = fitz.open(str(path))
        page_count = len(doc)
        metadata = doc.metadata
        doc.close()
        
        # Handle metadata safely
        safe_metadata = metadata or {}
        
        return {
            'filename': path.name,
            'size': stat.st_size,
            'size_formatted': format_file_size(stat.st_size),
            'page_count': page_count,
            'title': safe_metadata.get('title', ''),
            'author': safe_metadata.get('author', ''),
            'creator': safe_metadata.get('creator', ''),
            'producer': safe_metadata.get('producer', ''),
            'creation_date': safe_metadata.get('creationDate', ''),
            'modification_date': safe_metadata.get('modDate', '')
        }
        
    except Exception as e:
        return {
            'error': str(e)
        }

def format_file_size(size_bytes: int) -> str:
    """
    Format file size in human readable format
    
    Args:
        size_bytes: File size in bytes
        
    Returns:
        Formatted file size string
    """
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB"]
    i = 0
    size_value = float(size_bytes)
    
    while size_value >= 1024 and i < len(size_names) - 1:
        size_value /= 1024.0
        i += 1
    
    return f"{size_value:.1f} {size_names[i]}"

def estimate_reading_time(text: str, wpm: int = 200) -> dict:
    """
    Estimate reading time for extracted text
    
    Args:
        text: Text to analyze
        wpm: Words per minute reading speed (default: 200)
        
    Returns:
        Dictionary with word count and estimated reading time
    """
    words = len(text.split())
    minutes = words / wpm
    
    if minutes < 1:
        return {
            'words': words,
            'time': f"{int(minutes * 60)} seconds"
        }
    else:
        hours = int(minutes // 60)
        mins = int(minutes % 60)
        
        if hours > 0:
            time_str = f"{hours}h {mins}m"
        else:
            time_str = f"{mins}m"
        
        return {
            'words': words,
            'time': time_str
        }