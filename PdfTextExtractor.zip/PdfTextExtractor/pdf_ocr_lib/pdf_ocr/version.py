"""Version information for PDF OCR Library"""

__version__ = "1.0.0"