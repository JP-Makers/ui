"""
Setup script for PDF OCR Library
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README file
readme_file = Path(__file__).parent / "README.md"
readme_content = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read version
version = {}
version_file = Path(__file__).parent / "pdf_ocr" / "version.py"
exec(version_file.read_text(), version)

setup(
    name="pdf-ocr-lib",
    version=version["__version__"],
    description="A Python library for extracting text from PDFs with intelligent text box detection",
    long_description=readme_content,
    long_description_content_type="text/markdown",
    author="PDF OCR Library",
    author_email="",
    url="",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        "PyMuPDF>=1.20.0",
        "pdfplumber>=0.7.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black",
            "flake8",
        ]
    },
    entry_points={
        "console_scripts": [
            "pdf-ocr=pdf_ocr.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Text Processing",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="pdf ocr text extraction text-box",
    project_urls={
        "Documentation": "",
        "Source": "",
        "Bug Reports": "",
    },
)