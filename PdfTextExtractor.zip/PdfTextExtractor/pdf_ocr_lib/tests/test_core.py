#!/usr/bin/env python3
"""
Basic tests for PDF OCR Library
"""

import sys
import tempfile
from pathlib import Path

# Add parent directory to path so we can import the library
sys.path.insert(0, str(Path(__file__).parent.parent))

from pdf_ocr import SimplePDFOCR
from pdf_ocr.utils import validate_pdf_file, format_file_size

def test_basic_functionality():
    """Test basic OCR functionality"""
    print("Testing basic functionality...")
    
    # Create OCR instance
    ocr = SimplePDFOCR()
    assert ocr.min_font_size == 6.0
    assert ocr.line_tolerance == 3.0
    
    print("✓ OCR instance created successfully")

def test_text_box_detection():
    """Test text box detection logic"""
    print("Testing text box detection...")
    
    ocr = SimplePDFOCR()
    
    # Test cases for text box detection
    test_cases = [
        ("1.1", (0, 0, 50, 20), True),  # Numbered item
        ("A", (0, 0, 20, 20), True),    # Single letter
        ("123", (0, 0, 30, 20), True),  # Pure number
        ("This is a long paragraph", (0, 0, 200, 20), False),  # Normal text
        ("Hello", (0, 0, 150, 30), False),  # Regular word
    ]
    
    for text, bbox, expected in test_cases:
        result = ocr._is_text_box(text, bbox)
        assert result == expected, f"Failed for '{text}': expected {expected}, got {result}"
    
    print("✓ Text box detection working correctly")

def test_file_validation():
    """Test PDF file validation"""
    print("Testing file validation...")
    
    # Test with non-existent file
    assert not validate_pdf_file("nonexistent.pdf")
    
    # Test with invalid extension
    with tempfile.NamedTemporaryFile(suffix=".txt") as tmp:
        assert not validate_pdf_file(tmp.name)
    
    print("✓ File validation working correctly")

def test_utility_functions():
    """Test utility functions"""
    print("Testing utility functions...")
    
    # Test file size formatting
    assert format_file_size(0) == "0 B"
    assert format_file_size(1024) == "1.0 KB"
    assert format_file_size(1024 * 1024) == "1.0 MB"
    
    print("✓ Utility functions working correctly")

def run_all_tests():
    """Run all tests"""
    print("PDF OCR Library - Running Tests")
    print("=" * 30)
    
    try:
        test_basic_functionality()
        test_text_box_detection()
        test_file_validation()
        test_utility_functions()
        
        print("\n" + "=" * 30)
        print("✓ All tests passed!")
        
    except Exception as e:
        print(f"\n✗ Test failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    run_all_tests()