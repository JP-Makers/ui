# PDF OCR Library

## Overview

This is a Python-based PDF OCR library that combines text box content with normal text line by line with high accuracy. The core functionality extracts text from PDFs without image content, reading all text content including text boxes and tables. It's designed to handle cases like "1.1 Turn left" where "1.1" is in a text box format and "Turn left" is normal text, combining them into a single line "1.1 Turn left".

## System Architecture

The library follows a simple, focused architecture optimized for accurate PDF text extraction:

- **Core OCR Library**: Simple, efficient PDF text extraction without web complexity
- **Text Box Detection**: Intelligent identification of text boxes vs normal text
- **Line Grouping**: Spatial analysis to combine text elements on the same line
- **Output Formatting**: Clean, readable text output preserving logical structure

## Key Components

### Core Library

1. **SimplePDFOCR (`pdf_ocr.py`)**
   - Main library class for PDF OCR functionality
   - Uses PyMuPDF and pdfplumber for robust text extraction
   - Intelligent text box detection based on size, content patterns, and positioning
   - Line-by-line grouping with configurable tolerance
   - Simple API: `extract_text(pdf_path, page_numbers=None)`

2. **Text Box Detection**
   - Identifies numbered items (1.1, 2.3, etc.)
   - Detects short text elements (letters, symbols)
   - Recognizes small graphical elements
   - Distinguishes text boxes from normal paragraph text

3. **Supporting Files**
   - **utils.py**: Helper functions for file operations and validation
   - **README.md**: Complete documentation and usage examples

### Usage Examples

1. **Simple Usage (`example_usage.py`)**
   - Demonstrates basic OCR functionality
   - Shows statistics and page-specific extraction
   - Error handling examples

2. **Test Creation (`create_test_pdf.py`)**
   - Creates sample PDFs for testing
   - Demonstrates typical text box scenarios
   - Validation of OCR accuracy

## Data Flow

1. **PDF Input**: File path provided to SimplePDFOCR class
2. **Dual Extraction**: Text extracted using both PyMuPDF and pdfplumber for accuracy
3. **Text Box Detection**: Elements analyzed for text box characteristics (size, content, patterns)
4. **Line Grouping**: Text elements grouped by vertical position with configurable tolerance
5. **Smart Combination**: Text boxes and normal text combined in reading order
6. **Clean Output**: Formatted text returned with proper spacing and structure

## External Dependencies

### Core Libraries
- **PyMuPDF (fitz)**: Primary PDF parsing and text extraction
- **pdfplumber**: Secondary extraction for enhanced accuracy and validation

### Python Standard Library
- **sys**: Command-line argument handling
- **re**: Regular expression processing for text box detection
- **dataclasses**: Text element data structures
- **typing**: Type hints for better code quality

## Usage Patterns

### Simple Library Usage
```python
from pdf_ocr import SimplePDFOCR

ocr = SimplePDFOCR()
text = ocr.extract_text("document.pdf")
print(text)
```

### Command Line Usage
```bash
cd pdf_ocr_lib
python -m pdf_ocr document.pdf
python -m pdf_ocr document.pdf 1,3,5-10
# Or after installation: pdf-ocr document.pdf
```

### Library Structure
- **pdf_ocr_lib/**: Main library package with proper Python structure
  - **pdf_ocr/**: Core library package
    - **core.py**: Main SimplePDFOCR class and functionality
    - **utils.py**: Helper functions for file operations and validation
    - **cli.py**: Command line interface
    - **version.py**: Version information
  - **examples/**: Usage examples and demonstrations
  - **tests/**: Test suite for validation
  - **docs/**: Complete documentation
  - **setup.py** & **pyproject.toml**: Package configuration

## Recent Changes

- **July 04, 2025**: Created simplified PDF OCR library
  - Built `SimplePDFOCR` class for easy text extraction
  - Implemented intelligent text box detection (numbers, short phrases)
  - Added line-by-line combination of text boxes with normal text
  - Created command-line interface and example usage
  - Tested successfully with sample PDF showing "1.1 Turn left" format
  - Removed web interface and complex components per user request
  - Cleaned up project files to focus on core library functionality
  - Restructured into proper Python library format with clear organization
  - Added comprehensive documentation, examples, and test suite
  - Created installable package with CLI interface

## Core Features Delivered

- ✓ PDF text extraction without image content
- ✓ Text box detection and combination with normal text
- ✓ Line-by-line accurate reading ("1.1 Turn left" format)
- ✓ Support for tables and all text content
- ✓ Simple Python library interface
- ✓ Command-line usage
- ✓ Example code and documentation

## User Preferences

- Focus on usable library over web interface
- Simple, everyday language in documentation
- Accurate OCR functionality for text boxes and normal text combination